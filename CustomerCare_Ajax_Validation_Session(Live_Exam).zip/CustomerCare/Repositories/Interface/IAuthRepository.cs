using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Repositories.Models;

namespace Repositories.Interface
{
    public interface IAuthRepository
    {
        customercareModel login(customercareModel model);
        List<customerdataModel> getAlldatasession();
    }
}