using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Repositories.Models;

namespace Repositories.Interface
{
    public interface IcustomerRepository
    {
        List<customerdataModel> getAlldata();
        
        customerdataModel GetCustomer(int id);
        int AddCustomer(customerdataModel data);
        bool UpdateCustomer(customerdataModel data);
        List<customercareModel> gettoken();

    }
}