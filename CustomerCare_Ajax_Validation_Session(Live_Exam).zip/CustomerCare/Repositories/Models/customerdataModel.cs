using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Repositories.Models
{
    public class customerdataModel
    {
        public int c_customerid { get; set; }
        public int c_tokenid { get; set; }
        public int? c_userid { get; set; }
        public string? c_status { get; set; }
        public string? c_name { get; set; }
        public int? c_mobileno { get; set; } 
        public string c_tokentype { get; set; }
    }
}