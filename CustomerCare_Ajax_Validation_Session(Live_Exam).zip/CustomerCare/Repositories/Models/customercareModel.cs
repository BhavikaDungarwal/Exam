using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Repositories.Models
{
    public class customercareModel
    {
        public int c_userid { get; set; }
        public string c_loginid { get; set; }
        public string c_password { get; set; }
        public string c_tokentype { get; set; }
    }
}