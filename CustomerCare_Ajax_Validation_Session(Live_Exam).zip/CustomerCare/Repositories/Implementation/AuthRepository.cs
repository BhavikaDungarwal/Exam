using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Npgsql;
using Repositories.Interface;
using Repositories.Models;

namespace Repositories.Implementation
{
    public class AuthRepository : IAuthRepository
    {
        private readonly string _con;
        private IHttpContextAccessor httpContextAccessor;

        public AuthRepository(IConfiguration configuration, IHttpContextAccessor httpContext)
        {
            _con = configuration.GetConnectionString("DefaultConnection");
            httpContextAccessor = httpContext;
        }
        public customercareModel login(customercareModel model)
        {
            using (NpgsqlConnection con = new NpgsqlConnection(_con))
            {
                try
                {
                    con.Open();
                    string query = "SELECT * FROM t_customercare WHERE c_loginid = @c_loginid AND c_password = @c_password";
                    using (NpgsqlCommand cmd = new NpgsqlCommand(query, con))
                    {
                        cmd.CommandType = CommandType.Text;
                        cmd.Parameters.AddWithValue("@c_loginid", model.c_loginid);
                        cmd.Parameters.AddWithValue("@c_password", model.c_password);
                        using (NpgsqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                customercareModel data = new customercareModel
                                {
                                    c_userid = reader.GetInt32(0),
                                    c_loginid = reader.GetString(1),
                                    c_password = reader.GetString(2),
                                    c_tokentype = reader.GetString(3)
                                };
                                return data;
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                return null;
            }
        }



        public List<customerdataModel> getAlldatasession()
        {
            List<customerdataModel> data = new List<customerdataModel>();
            using (NpgsqlConnection con = new NpgsqlConnection(_con))
            {
                try
                {
                    var userId = httpContextAccessor.HttpContext.Session.GetInt32("userId");
                    con.Open();
                    string query = "SELECT * FROM t_customerdata WHERE c_userid =@id AND c_status = 'pending'";
                    using (NpgsqlCommand cmd = new NpgsqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@id", userId);
                        using (NpgsqlDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                customerdataModel emp = new customerdataModel
                                {
                                    c_customerid = Convert.ToInt32(reader["c_customerid"]),
                                    c_tokenid = Convert.ToInt32(reader["c_tokenid"]),
                                    c_status = reader["c_status"] != DBNull.Value ? reader["c_status"].ToString() : null,
                                    c_name = reader["c_name"] != DBNull.Value ? reader["c_name"].ToString() : null,
                                    c_mobileno = reader["c_mobileno"] != DBNull.Value ? Convert.ToInt32(reader["c_mobileno"]) : (int?)null,
                                    c_userid = reader["c_userid"] != DBNull.Value ? Convert.ToInt32(reader["c_userid"]) : (int?)null
                                };
                                data.Add(emp);
                            }
                            return data;
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    return null;
                }
            }
        }
    }
}