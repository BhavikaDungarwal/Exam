using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using Npgsql;
using Repositories.Interface;
using Repositories.Models;
using Microsoft.AspNetCore.Http;

namespace Repositories.Implementation
{
    public class customerRepository : IcustomerRepository
    {
        public readonly string _con;
        private IHttpContextAccessor httpContextAccessor;

        public customerRepository(IConfiguration configuration, IHttpContextAccessor httpContext)
        {
            _con = configuration.GetConnectionString("DefaultConnection");
            httpContextAccessor = httpContext;
        }
        public int AddCustomer(customerdataModel data)
{
    using (NpgsqlConnection con = new NpgsqlConnection(_con))
    {
        try
        {
            con.Open();
            string query = "INSERT INTO t_customerdata VALUES(DEFAULT,DEFAULT, @c_userid, @c_status, @c_name, @c_mobileno) returning c_tokenid";
            using (NpgsqlCommand cmd = new NpgsqlCommand(query, con))
            {
                cmd.Parameters.AddWithValue("@c_userid", data.c_userid);
                cmd.Parameters.AddWithValue("@c_status", data.c_status);
                cmd.Parameters.AddWithValue("@c_name", string.IsNullOrEmpty(data.c_name) ? DBNull.Value : (object)data.c_name);
                cmd.Parameters.AddWithValue("@c_mobileno", data.c_mobileno.HasValue ? (object)data.c_mobileno.Value : DBNull.Value);
                
                object result = cmd.ExecuteScalar();
                if (result != DBNull.Value && result != null)
                {
                    return Convert.ToInt32(result);
                }
                return 0; 
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine(ex.Message);
            return 0; 
        }
    }
}


        public customerdataModel GetCustomer(int id)
        {
            using (NpgsqlConnection con = new NpgsqlConnection(_con))
            {
                try
                {
                    con.Open();
                    string query = "SELECT * FROM t_customerdata WHERE c_customerid = @id  ";
                    using (NpgsqlCommand cmd = new NpgsqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@id", id);
                        cmd.CommandType = CommandType.Text;
                        using (NpgsqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                customerdataModel emp = new customerdataModel
                                {
                                    c_customerid = Convert.ToInt32(reader["c_customerid"]),
                                    c_tokenid = Convert.ToInt32(reader["c_tokenid"]),
                                    c_status = reader["c_status"].ToString(),
                                    c_name = reader["c_name"] != DBNull.Value ? reader["c_name"].ToString() : null,
                                    c_mobileno = reader["c_mobileno"] != DBNull.Value ? Convert.ToInt32(reader["c_mobileno"]) : 0,
                                    c_userid = Convert.ToInt32(reader["c_userid"])
                                };
                                return emp;
                            }
                            else
                            {
                                return null;
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    return null;
                }
            }
        }


        public List<customercareModel> gettoken()
        {
            List<customercareModel> data = new List<customercareModel>();
            using (NpgsqlConnection con = new NpgsqlConnection(_con))
            {
                try
                {

                    con.Open();
                    string query = "SELECT c_userid , c_tokentype FROM t_customercare";
                    using (NpgsqlCommand cmd = new NpgsqlCommand(query, con))
                    {
                        cmd.CommandType = CommandType.Text;
                        using (NpgsqlDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                customercareModel emp = new customercareModel
                                {
                                    c_userid = Convert.ToInt16(reader["c_userid"]),
                                    c_tokentype = reader["c_tokentype"].ToString(),
                                };
                                data.Add(emp);
                            }
                            return data;
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    return null;
                }
            }
        }

        public List<customerdataModel> getAlldata()
        {
            List<customerdataModel> data = new List<customerdataModel>();
            using (NpgsqlConnection con = new NpgsqlConnection(_con))
            {
                try
                {

                    con.Open();
                    string query = "SELECT * FROM t_customerdata where c_status = 'pending' ";
                    using (NpgsqlCommand cmd = new NpgsqlCommand(query, con))
                    {
                        cmd.CommandType = CommandType.Text;
                        using (NpgsqlDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                customerdataModel emp = new customerdataModel
                                {
                                    c_customerid = Convert.ToInt32(reader["c_customerid"]),
                                    c_tokenid = Convert.ToInt32(reader["c_tokenid"]),
                                    c_status = reader["c_status"] != DBNull.Value ? reader["c_status"].ToString() : null,
                                    c_name = reader["c_name"] != DBNull.Value ? reader["c_name"].ToString() : null,
                                    c_mobileno = reader["c_mobileno"] != DBNull.Value ? Convert.ToInt32(reader["c_mobileno"]) : (int?)null,
                                    c_userid = reader["c_userid"] != DBNull.Value ? Convert.ToInt32(reader["c_userid"]) : (int?)null
                                };
                                data.Add(emp);
                            }
                            return data;
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    return null;
                }
            }
        }







        public bool UpdateCustomer(customerdataModel data)
        {
            using (NpgsqlConnection con = new NpgsqlConnection(_con))
            {
                try
                {
                    con.Open();
                    string query = "UPDATE t_customerdata SET  c_userid = @c_userid, c_status = @c_status, c_name = @c_name, c_mobileno = @c_mobileno WHERE c_customerid = @c_customerid";
                    using (NpgsqlCommand cmd = new NpgsqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@c_userid", data.c_userid);
                        cmd.Parameters.AddWithValue("@c_status", data.c_status);
                        cmd.Parameters.AddWithValue("@c_name", data.c_name);
                        cmd.Parameters.AddWithValue("@c_mobileno", data.c_mobileno);
                        cmd.Parameters.AddWithValue("@c_customerid", data.c_customerid);
                        int rowsAffected = cmd.ExecuteNonQuery();
                        return rowsAffected > 0;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    return false;
                }
            }
        }



    }
}