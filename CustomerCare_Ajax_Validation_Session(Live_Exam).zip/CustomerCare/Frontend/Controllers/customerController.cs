using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Repositories.Interface;
using Repositories.Models;

namespace Frontend.Controllers
{
    public class customerController : Controller
    {
        private readonly ILogger<customerController> _logger;

        private IcustomerRepository _icustomerrepository;

        public customerController(ILogger<customerController> logger, IcustomerRepository icustomerrepository)
        {
            _logger = logger;
            _icustomerrepository = icustomerrepository;
        }

        public IActionResult Index()
        {

            return View();
        }


        public IActionResult Add(customerdataModel customerdata)
        {
            customerdata.c_status = "pending";
            var c_tokenid = _icustomerrepository.AddCustomer(customerdata);
            if (c_tokenid != -1)
            {
                return Json(new { c_tokenid = c_tokenid });
            }
            else
            {
                return BadRequest(); // Return a 400 error if token id is not available
            }
        }
        public IActionResult gettokens()
        {
            var data = _icustomerrepository.gettoken();
            return Json(data);
        }

        public IActionResult getcustomer()
        {
            var data = _icustomerrepository.getAlldata();
            return Json(data);
        }


        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View("Error!");
        }
    }
}