using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Repositories.Interface;
using Repositories.Models;

namespace Frontend.Controllers
{
    public class ExecutiveController : Controller
    {
        private readonly ILogger<ExecutiveController> _logger;

        private IAuthRepository _iacustomerrepository;
        private IcustomerRepository _icustomerrepository;

        public ExecutiveController(ILogger<ExecutiveController> logger, IAuthRepository iacustomerrepository, IcustomerRepository icustomerRepository)
        {
            _logger = logger;
            _iacustomerrepository = iacustomerrepository;
            _icustomerrepository = icustomerRepository;
        }

        public IActionResult Index()
        {
            // int? id = HttpContext.Session.GetInt32("userId");
            // string? tokentype = HttpContext.Session.GetString("tokentype");
            // TempData["id"] = id;
            // TempData["tokentype"] = tokentype;
            return View();
        }

        public IActionResult getcustomer()
        {
            var data = _iacustomerrepository.getAlldatasession();
            return Json(data);
        }

       

        public IActionResult getParticularData(int id)
        {
            var custmodel = _icustomerrepository.GetCustomer(id);
            return Json(custmodel);
        }
        public IActionResult Edit(customerdataModel model)
        {
            model.c_status = "resolve";
            var custmodel = _icustomerrepository.UpdateCustomer(model);
            return Json(custmodel);
        }



        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View("Error!");
        }
    }
}