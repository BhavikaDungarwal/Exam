﻿using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Frontend.Models;
using Repositories.Interface;
using Repositories.Models;

namespace Frontend.Controllers;

public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;

    private IAuthRepository _authRepository;

    public HomeController(ILogger<HomeController> logger, IAuthRepository authRepository)
    {
        _logger = logger;
        _authRepository = authRepository;
    }



    public IActionResult Index()
    {

        return View();
    }

    [HttpPost]
    public IActionResult login(customercareModel auth)
    {
        var data = _authRepository.login(auth);
        HttpContext.Session.SetInt32("userId", data.c_userid);
        HttpContext.Session.SetString("tokentype", data.c_tokentype);
        return Json(data);
    }


    public IActionResult logout()
    {
        HttpContext.Session.Clear();
        return RedirectToAction("Index", "Home");
    }




    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}
