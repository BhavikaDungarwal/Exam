using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Exam.Models
{
    public class FieldModel
    {
        public int c_fid { get; set; }
        public string c_fieldname { get; set; }
    }
}