using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Exam.Models
{
    public class EmpModel
    {
        public int c_empid { get; set; }
        public string c_empname { get; set; }
        public string c_gender { get; set; }
        public string c_language { get; set; }
        public int c_fid { get; set; }
        public DateTime c_date { get; set; }
        public string c_sphoto { get; set; }
        public decimal c_phoneno { get; set; }
        public int c_userid { get; set; }
        public string c_fieldname { get; set; }
    }
}