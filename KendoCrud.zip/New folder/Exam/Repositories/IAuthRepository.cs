using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Exam.Models;

namespace Exam.Repositories
{
    public interface IAuthRepository
    {
        AuthModel Login(AuthModel auths);
        bool Register(AuthModel auth);
    }
}