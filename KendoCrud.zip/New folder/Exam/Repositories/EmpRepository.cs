using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Exam.Models;
using Npgsql;

namespace Exam.Repositories
{
    public class EmpRepository : IEmpRepository
    {
        private readonly string _conn;
        private readonly IHttpContextAccessor _httpContextAccessor;
        public EmpRepository(IConfiguration configuration, IHttpContextAccessor httpContextAccessor)
        {
            _conn = configuration.GetConnectionString("Default");
            _httpContextAccessor = httpContextAccessor;
        }
        public void Delete(int id)
        {
            try
            {
                using NpgsqlConnection conn = new NpgsqlConnection(_conn);
                conn.Open();
                using NpgsqlCommand cmd = new NpgsqlCommand("delete from t_emp where c_empid = @c_empid", conn);
                cmd.Parameters.AddWithValue("@c_empid", id);
                cmd.CommandType = CommandType.Text;
                cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }

        public List<FieldModel> GetAllField()
        {
            List<FieldModel> cities = new List<FieldModel>();
            try
            {
                using NpgsqlConnection conn = new NpgsqlConnection(_conn);
                conn.Open();
                using (NpgsqlCommand cmd = new NpgsqlCommand("Select * from t_field", conn))
                using (NpgsqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        FieldModel city = new FieldModel
                        {
                            c_fid = Convert.ToInt32(reader["c_fid"]),
                            c_fieldname = reader["c_fieldname"].ToString()
                        };
                        cities.Add(city);
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            return cities;
        }

        public List<EmpModel> GetAllData()
        {
            List<EmpModel> datas = new List<EmpModel>();
            try
            {
                using NpgsqlConnection conn = new NpgsqlConnection(_conn);
                conn.Open();
                var http = _httpContextAccessor.HttpContext;
                var userid = http.Session.GetInt32("Userid");
                using (NpgsqlCommand cmd = new NpgsqlCommand("select k.c_empid, k.c_empname, k.c_fid, k.c_gender, k.c_date, k.c_language, k.c_sphoto, k.c_phoneno,k.c_userid, c.c_fieldname from t_emp k join t_field c on k.c_fid=c.c_fid where c_userid = @userid", conn))
                {
                    cmd.Parameters.AddWithValue("@userid", userid);
                    using (NpgsqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            EmpModel data = new EmpModel
                            {
                                c_empid = Convert.ToInt32(reader["c_empid"]),
                                c_empname = reader["c_empname"].ToString(),
                                c_fid = Convert.ToInt32(reader["c_fid"]),
                                c_gender = reader["c_gender"].ToString(),
                                c_date = Convert.ToDateTime(reader["c_date"]),
                                c_language = reader["c_language"].ToString(),
                                c_sphoto = reader["c_sphoto"].ToString(),
                                c_phoneno = Convert.ToDecimal(reader["c_phoneno"]),
                                c_userid = Convert.ToInt32(reader["c_userid"]),
                                c_fieldname = reader["c_fieldname"].ToString()
                            };
                            datas.Add(data);
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            return datas;

        }

        public bool Insert(EmpModel state)
        {
            try
            {
                using NpgsqlConnection conn = new NpgsqlConnection(_conn);
                conn.Open();

                // Ensure c_phoneno is not null and is a numeric value
                if (state.c_phoneno != null && state.c_phoneno is decimal)
                {
                    using NpgsqlCommand cmd = new NpgsqlCommand("INSERT INTO t_emp (c_empname, c_fid, c_gender, c_date, c_language, c_sphoto, c_phoneno, c_userid) VALUES (@c_empname, @c_fid, @c_gender, @c_date, @c_language, @c_sphoto, @c_phoneno, @c_userid)", conn);
                    cmd.Parameters.AddWithValue("@c_empname", state.c_empname);
                    cmd.Parameters.AddWithValue("@c_fid", state.c_fid);
                    cmd.Parameters.AddWithValue("@c_gender", state.c_gender);
                    cmd.Parameters.AddWithValue("@c_date", state.c_date);
                    cmd.Parameters.AddWithValue("@c_language", state.c_language);
                    cmd.Parameters.AddWithValue("@c_sphoto", state.c_sphoto);
                    cmd.Parameters.AddWithValue("@c_phoneno", state.c_phoneno);
                    cmd.Parameters.AddWithValue("@c_userid", state.c_userid);
                    cmd.CommandType = CommandType.Text;
                    cmd.ExecuteNonQuery();
                    return true;
                }
                else
                {
                    // Handle the case where c_phoneno is null or not a numeric value
                    Console.WriteLine("c_phoneno is null or not a numeric value.");
                    return false;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("Error inserting data: " + e.Message);
                return false;
            }
        }

        public void multidelete(List<int> ids)
        {
            try
            {
                using NpgsqlConnection conn = new NpgsqlConnection(_conn);
                conn.Open();
                using NpgsqlCommand cmd = new NpgsqlCommand($"delete from t_emp where c_empid IN ({string.Join(",", ids)})", conn);
                cmd.CommandType = CommandType.Text;
                cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }

        public bool Update(EmpModel state)
        {
            try
            {
                using NpgsqlConnection conn = new NpgsqlConnection(_conn);
                conn.Open();
                using NpgsqlCommand cmd = new NpgsqlCommand("update t_emp set c_empname=@c_empname,c_fid=@c_fid,c_gender=@c_gender,c_date=@c_date,c_language=@c_language,c_sphoto=@c_sphoto, c_phoneno=@c_phoneno,c_userid = @c_userid where c_empid=@c_empid", conn);
                cmd.Parameters.AddWithValue("@c_empid", state.c_empid);
                cmd.Parameters.AddWithValue("@c_empname", state.c_empname);
                cmd.Parameters.AddWithValue("@c_fid", state.c_fid);
                cmd.Parameters.AddWithValue("@c_gender", state.c_gender);
                cmd.Parameters.AddWithValue("@c_date", state.c_date);
                cmd.Parameters.AddWithValue("@c_language", state.c_language);
                cmd.Parameters.AddWithValue("@c_sphoto", state.c_sphoto);
                cmd.Parameters.AddWithValue("@c_phoneno", state.c_phoneno);
                cmd.Parameters.AddWithValue("@c_userid", state.c_userid);
                cmd.CommandType = CommandType.Text;
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                return false;
            }
        }
    }
}