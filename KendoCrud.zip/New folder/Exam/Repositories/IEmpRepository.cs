using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Exam.Models;

namespace Exam.Repositories
{
    public interface IEmpRepository
    {
        void Delete(int id);
        List<FieldModel> GetAllField();
        List<EmpModel> GetAllData();
        bool Insert(EmpModel state);
        void multidelete(List<int> ids);
        bool Update(EmpModel state);
    }
}