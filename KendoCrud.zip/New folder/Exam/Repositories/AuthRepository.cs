using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Exam.Models;
using Npgsql;

namespace Exam.Repositories
{
    public class AuthRepository : IAuthRepository
    {
        private readonly string _conn;
        private readonly IHttpContextAccessor _httpContextAccessor;
        public AuthRepository(IConfiguration configuration, IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
            _conn = configuration.GetConnectionString("Default");
        }
        public AuthModel Login(AuthModel auths)
        {
            try
            {
                using NpgsqlConnection conn = new NpgsqlConnection(_conn);
                conn.Open();
                using NpgsqlCommand cmd = new NpgsqlCommand("select * from t_auth where c_email=@email and c_password=@password", conn);
                cmd.Parameters.AddWithValue("@email", auths.c_email);
                cmd.Parameters.AddWithValue("@password", auths.c_password);
                cmd.CommandType = CommandType.Text;
                using (NpgsqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        var http = _httpContextAccessor.HttpContext;
                        http.Session.SetString("Email", auths.c_email);
                        AuthModel auth = new AuthModel
                        {
                            c_userid = Convert.ToInt16(reader["c_userid"]),
                            c_username = reader["c_username"].ToString(),
                            c_email = reader["c_email"].ToString(),
                            c_password = reader["c_password"].ToString(),
                            c_status = Convert.ToInt16(reader["c_status"]),
                        };
                        http.Session.SetInt32("Userid", auth.c_userid);
                        return auth;
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }

            return null;
        }
        // public bool Login(AuthModel auths)
        // {
        //     try
        //     {
        //         conn.Open();
        //         using NpgsqlCommand cmd = new NpgsqlCommand("select Count(*) from t_user where c_email=@email and c_password=@password",conn);
        //         cmd.Parameters.AddWithValue("@email",auths.c_email);
        //         cmd.Parameters.AddWithValue("@password",auths.c_password);
        //         cmd.CommandType=CommandType.Text;
        //         int result = Convert.ToInt32(cmd.ExecuteScalar());
        //         if(result>0)
        //         {
        //             var http=_httpContextAccessor.HttpContext;
        //             http.Session.SetString("Email",auths.c_email);
        //             return true;
        //         }
        //         return false;
        //     }
        //     catch(Exception e)
        //     {
        //         Console.WriteLine(e.Message);
        //         return false;
        //     }
        //     finally
        //     {
        //         conn.Close();
        //     }
        // }

        public bool Register(AuthModel auth)
        {
            try
            {
                using NpgsqlConnection conn = new NpgsqlConnection(_conn);
                conn.Open();
                using NpgsqlCommand cmd = new NpgsqlCommand("insert into t_auth values(default,@name,@email,@password,@status)", conn);
                cmd.Parameters.AddWithValue("@name", auth.c_username);
                cmd.Parameters.AddWithValue("@email", auth.c_email);
                cmd.Parameters.AddWithValue("@password", auth.c_password);
                cmd.Parameters.AddWithValue("@status", 0);
                cmd.CommandType = CommandType.Text;
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                return false;
            }
        }
    }
}