using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Exam.Models;
using Exam.Repositories;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace Exam.Controllers
{
    public class AuthController : Controller
    {
        private readonly ILogger<AuthController> _logger;
        private readonly IAuthRepository _authRepository;

        public AuthController(ILogger<AuthController> logger, IAuthRepository authRepository)
        {
            _logger = logger;
            _authRepository = authRepository;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Register()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Register(AuthModel auth)
        {
            var data = _authRepository.Register(auth);
            if (data)
            {
                return RedirectToAction("Login");
            }
            else
            {
                return View(auth);
            }
        }


        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Login(AuthModel authModel)
        {
            // if(_authRepository.Login(authModel))
            // {
            //     return RedirectToAction("Index","City");
            // }
            // else
            // {
            //     ViewBag.ml="User Id invailid";
            //     return View();
            // }
            var data = _authRepository.Login(authModel);
            if (data != null)
            {
                if (data.c_status == 1)
                {
                    return RedirectToAction("Index", "Emp");
                }
                else
                {
                    return RedirectToAction("Index", "Home");

                }
            }
            else
            {
                ViewBag.ml = "Invalid Credential";
                return View();
            }
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View("Error!");
        }
    }
}