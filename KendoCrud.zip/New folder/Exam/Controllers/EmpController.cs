using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Exam.Models;
using Exam.Repositories;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace Exam.Controllers
{
    public class EmpController : Controller
    {
        private readonly ILogger<EmpController> _logger;
        private readonly IEmpRepository _empRepository;
        private IWebHostEnvironment _webHostEnvironment;

        public EmpController(ILogger<EmpController> logger, IEmpRepository empRepository, IWebHostEnvironment webHostEnvironment)
        {
            _empRepository = empRepository;
            _webHostEnvironment = webHostEnvironment;
            _logger = logger;
        }

        public IActionResult Index()
        {
            TempData["Email"] = HttpContext.Session.GetString("Email");
            TempData["Userid"] = HttpContext.Session.GetInt32("Userid");
            return View();
        }

        [HttpPost]
        public IActionResult UploadPhoto(IFormFile? photo)
        {
            try
            {
                if (photo != null)
                {
                    string filename = Guid.NewGuid().ToString() + Path.GetExtension(photo.FileName);
                    string filepath = Path.Combine(_webHostEnvironment.WebRootPath, "photos", filename);

                    using (var stream = new FileStream(filepath, FileMode.Create))
                    {
                        photo.CopyTo(stream);
                    }

                    var empModel = new EmpModel { c_sphoto = filename };
                    _empRepository.Insert(empModel);

                    return Json(new { success = true, filename });
                }
                else
                {
                    return Json(new { success = false, message = "No file uploaded" });
                }
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }
        public IActionResult ViewField()
        {
            var cities = _empRepository.GetAllField();
            return Json(cities);
        }

        public IActionResult ViewData()
        {
            var datas = _empRepository.GetAllData();
            return Json(datas);
        }

        [HttpPost]
        public IActionResult Index(EmpModel empModel)
        {
            _empRepository.Insert(empModel);
            return Json(new { success = true });
        }

        public IActionResult Delete(int id)
        {
            _empRepository.Delete(id);
            return Json(new { success = true });
        }

        [HttpPost]
        public IActionResult Multidelete([FromBody] List<int> ids)
        {
            if (ids != null && ids.Count > 0)
            {
                _empRepository.multidelete(ids);
            }
            return Json(new { success = true });
        }

        [HttpPost]
        public IActionResult update(EmpModel empModel)
        {
            _empRepository.Update(empModel);
            return Json(new { success = true });
        }



        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View("Error!");
        }
    }
}