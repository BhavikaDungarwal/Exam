using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Mvc.Models;
using Mvc.Repositories;

namespace Mvc.Controllers
{
    public class StudentController : Controller
    {
        private readonly ILogger<StudentController> _logger;

        private readonly IStudentRepository _studRepository;

        public StudentController(ILogger<StudentController> logger, IStudentRepository studRepository)
        {
            _logger = logger;
            _studRepository = studRepository;
        }

        public IActionResult Index()
        {
            TempData["Email"] = HttpContext.Session.GetString("Email");
            TempData["Userid"] = HttpContext.Session.GetInt32("Userid");
            return View();
        }
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Login(StudentModel authModel)
        {
            var data = _studRepository.Login(authModel);
            if (data != null)
            {
                return RedirectToAction("Index", "Student");
            }
            else
            {
                TempData["error"] = "Invalid Credential";
                return View();
            }
        }

        public IActionResult ViewCat()
        {
            var data = _studRepository.GetAllCategory();
            return Json(data);
        }

        public IActionResult ViewBook(int catid)
        {
            var data = _studRepository.GetAllBook(catid);
            return Json(data);
        }
        public IActionResult ViewBooks()
        {
            var data = _studRepository.GetAllBooks();
            return Json(data);
        }
        public IActionResult ViewStatusData()
        {
            var data = _studRepository.GetAllStatus();
            return Json(data);
        }

        [HttpPost]
        public IActionResult Index(StatusModel statusModel)
        {
            _studRepository.StatusInsert(statusModel);
            return Json(new { success = true });
        }
        [HttpPost]
        public IActionResult Rejected(int id)
        {
            _studRepository.Rejected(id);
            return Json(new { success = true });
        }





        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View("Error!");
        }
    }
}