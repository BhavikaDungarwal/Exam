using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Mvc.Models;
using Mvc.Repositories;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace Mvc.Controllers
{
    public class BookController : Controller
    {
        private readonly ILogger<BookController> _logger;
        private readonly IBookRepository _bookRepository;
        private readonly IStudentRepository _studRepository;
        private IWebHostEnvironment _webHostEnvironment;

        public BookController(ILogger<BookController> logger, IBookRepository bookRepository, IWebHostEnvironment webHostEnvironment, IStudentRepository studentRepository)
        {
            _bookRepository = bookRepository;
            _webHostEnvironment = webHostEnvironment;
            _studRepository = studentRepository;
            _logger = logger;
        }

        public IActionResult Index()
        {
            TempData["Email"] = HttpContext.Session.GetString("Email");
            TempData["Userid"] = HttpContext.Session.GetInt32("Userid");
            return View();
        }
        public IActionResult Student()
        {
            TempData["Email"] = HttpContext.Session.GetString("Email");
            TempData["Userid"] = HttpContext.Session.GetInt32("Userid");
            return View();
        }
        public IActionResult Status()
        {
            TempData["Email"] = HttpContext.Session.GetString("Email");
            TempData["Userid"] = HttpContext.Session.GetInt32("Userid");
            return View();
        }


        [HttpPost]
        public IActionResult UploadPhoto(IFormFile? photo)
        {
            try
            {
                if (photo != null)
                {
                    string filename = Guid.NewGuid().ToString() + Path.GetExtension(photo.FileName);
                    string filepath = Path.Combine(_webHostEnvironment.WebRootPath, "photos", filename);

                    using (var stream = new FileStream(filepath, FileMode.Create))
                    {
                        photo.CopyTo(stream);
                    }

                    var studModel = new StudentModel { c_sphoto = filename };
                    _studRepository.Insert(studModel);

                    return Json(new { success = true, filename });
                }
                else
                {
                    return Json(new { success = false, message = "No file uploaded" });
                }
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = ex.Message });
            }
        }

        public IActionResult ViewField()
        {
            var data = _studRepository.GetAllField();
            return Json(data);
        }

        public IActionResult ViewStudData()
        {
            var datas = _studRepository.GetAllData();
            return Json(datas);
        }

        [HttpPost]
        public IActionResult Student(StudentModel studModel)
        {
            _studRepository.Insert(studModel);
            return Json(new { success = true });
        }
        public IActionResult ViewCat()
        {
            var data = _bookRepository.GetAllCategory();
            return Json(data);
        }
        public IActionResult ViewStatusData()
        {
            var data = _bookRepository.GetAllStatus();
            return Json(data);
        }

        public IActionResult ViewData()
        {
            var datas = _bookRepository.GetAllData();
            return Json(datas);
        }

        [HttpPost]
        public IActionResult Index(BookModel bookModel)
        {
            _bookRepository.Insert(bookModel);
            return Json(new { success = true });
        }

        public IActionResult Delete(int id)
        {
            _bookRepository.Delete(id);
            return Json(new { success = true });
        }

        [HttpPost]
        public IActionResult Multidelete([FromBody] List<int> ids)
        {
            if (ids != null && ids.Count > 0)
            {
                _bookRepository.multidelete(ids);
            }
            return Json(new { success = true });
        }

        [HttpPost]
        public IActionResult update(BookModel bookModel)
        {
            _bookRepository.Update(bookModel);
            return Json(new { success = true });
        }
        [HttpPost]
        public IActionResult Approved(int id)
        {
            _bookRepository.Approved(id);
            return Json(new { success = true });
        }
        [HttpPost]
        public IActionResult Rejected(int id)
        {
            _bookRepository.Rejected(id);
            return Json(new { success = true });
        }



        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View("Error!");
        }
    }
}