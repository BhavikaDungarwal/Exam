using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Mvc.Models;

namespace Mvc.Repositories
{
    public interface IAuthRepository
    {
        AuthModel Login(AuthModel auths);
    }
}