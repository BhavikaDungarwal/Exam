using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Mvc.Models;
using Npgsql;

namespace Mvc.Repositories
{
    public class BookRepository : IBookRepository
    {
        private readonly string _conn;
        private readonly IHttpContextAccessor _httpContextAccessor;
        public BookRepository(IConfiguration configuration, IHttpContextAccessor httpContextAccessor)
        {
            _conn = configuration.GetConnectionString("DefaultConnection");
            _httpContextAccessor = httpContextAccessor;
        }
        public void Delete(int id)
        {
           
            try
            {
                using NpgsqlConnection conn = new NpgsqlConnection(_conn);
                conn.Open();
                using NpgsqlCommand cmd = new NpgsqlCommand("delete from t_bookdetail where c_bookid = @c_bookid", conn);
                cmd.Parameters.AddWithValue("@c_bookid", id);
                cmd.CommandType = CommandType.Text;
                cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }

        public List<CategoryModel> GetAllCategory()
        {
            List<CategoryModel> categories = new List<CategoryModel>();
            try
            {
                using (NpgsqlConnection conn = new NpgsqlConnection(_conn))
                {
                    conn.Open();
                    using (NpgsqlCommand cmd = new NpgsqlCommand("Select * from t_category", conn))
                    {
                        using (NpgsqlDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                CategoryModel category = new CategoryModel
                                {
                                    c_catid = Convert.ToInt32(reader["c_catid"]),
                                    c_catname = reader["c_catname"].ToString()
                                };
                                categories.Add(category);
                            }
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            return categories;
        }

        public List<BookModel> GetAllData()
        {
            List<BookModel> datas = new List<BookModel>();
            try
            {
                using NpgsqlConnection conn = new NpgsqlConnection(_conn);
                conn.Open();
                using (NpgsqlCommand cmd = new NpgsqlCommand("select k.c_bookid, k.c_bookname, k.c_initialstock, k.c_availstock, k.c_date,k.c_catid, c.c_catname from t_bookdetail k join t_category c on k.c_catid=c.c_catid", conn))
                {
                    using (NpgsqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            BookModel data = new BookModel
                            {
                                c_bookid = Convert.ToInt32(reader["c_bookid"]),
                                c_bookname = reader["c_bookname"].ToString(),
                                c_catid = Convert.ToInt32(reader["c_catid"]),
                                c_initialstock = Convert.ToInt32(reader["c_initialstock"]),
                                c_availstock = Convert.ToInt32(reader["c_availstock"]),
                                c_date = Convert.ToDateTime(reader["c_date"]),
                                c_catname = reader["c_catname"].ToString(),
                            };
                            datas.Add(data);
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            return datas;

        }

        public bool Insert(BookModel book)
        {
            try
            {
                using NpgsqlConnection conn = new NpgsqlConnection(_conn);
                conn.Open();

                using NpgsqlCommand cmd = new NpgsqlCommand("INSERT INTO t_bookdetail (c_catid,c_bookname,  c_initialstock, c_availstock, c_date) VALUES (@c_catid,@c_bookname,  @c_initialstock, @c_availstock, @c_date)", conn);
                cmd.Parameters.AddWithValue("@c_catid", book.c_catid);
                cmd.Parameters.AddWithValue("@c_bookname", book.c_bookname);
                cmd.Parameters.AddWithValue("@c_initialstock", book.c_initialstock);
                cmd.Parameters.AddWithValue("@c_availstock", book.c_availstock);
                cmd.Parameters.AddWithValue("@c_date", book.c_date);
                cmd.CommandType = CommandType.Text;
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (Exception e)
            {
                Console.WriteLine("Error inserting data: " + e.Message);
                return false;
            }
        }

        public void multidelete(List<int> ids)
        {
            try
            {
                using NpgsqlConnection conn = new NpgsqlConnection(_conn);
                conn.Open();
                using NpgsqlCommand cmd = new NpgsqlCommand($"delete from t_bookdetail where c_bookid IN ({string.Join(",", ids)})", conn);
                cmd.CommandType = CommandType.Text;
                cmd.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }

        public bool Update(BookModel book)
        {
            try
            {
                using NpgsqlConnection conn = new NpgsqlConnection(_conn);
                conn.Open();
                using NpgsqlCommand cmd = new NpgsqlCommand("update t_bookdetail set c_catid=@c_catid,c_bookname=@c_bookname,c_initialstock=@c_initialstock,c_availstock=@c_availstock,c_date=@c_date where c_bookid=@c_bookid", conn);
                cmd.Parameters.AddWithValue("@c_bookid", book.c_bookid);
                cmd.Parameters.AddWithValue("@c_catid", book.c_catid);
                cmd.Parameters.AddWithValue("@c_bookname", book.c_bookname);
                cmd.Parameters.AddWithValue("@c_initialstock", book.c_initialstock);
                cmd.Parameters.AddWithValue("@c_availstock", book.c_availstock);
                cmd.Parameters.AddWithValue("@c_date", book.c_date);
                cmd.CommandType = CommandType.Text;
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                return false;
            }
        }

        public List<StatusModel> GetAllStatus()
        {
            List<StatusModel> status = new List<StatusModel>();
            try
            {
                using NpgsqlConnection conn = new NpgsqlConnection(_conn);
                conn.Open();
                var http = _httpContextAccessor.HttpContext;
                var sid = http.Session.GetInt32("Userid");
                using (NpgsqlCommand cmd = new NpgsqlCommand("Select t_status.c_statusid,t_status.c_sid,t_status.c_statusreturn,t_status.c_statusapproved,t_status.c_catid,t_status.c_bookid,t_status.c_date, t_category.c_catname,t_bookdetail.c_bookname from t_status join t_category on t_status.c_catid = t_category.c_catid join t_bookdetail on t_status.c_bookid = t_bookdetail.c_bookid order by t_status.c_statusid", conn))
                {
                    cmd.Parameters.AddWithValue("@sid", sid);
                    using (NpgsqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            StatusModel st = new StatusModel
                            {
                                c_statusid = Convert.ToInt32(reader["c_statusid"]),
                                c_sid = Convert.ToInt32(reader["c_sid"]),
                                c_catid = Convert.ToInt32(reader["c_catid"]),
                                c_bookid = Convert.ToInt32(reader["c_bookid"]),
                                c_date = Convert.ToDateTime(reader["c_date"]),
                                c_catname = reader["c_catname"].ToString(),
                                c_statusreturn = reader["c_statusreturn"].ToString(),
                                c_statusapproved = reader["c_statusapproved"].ToString(),
                                c_bookname = reader["c_bookname"].ToString(),
                            };
                            status.Add(st);
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            return status;
        }

        public bool Approved(int id)
        {
            try
            {
                using NpgsqlConnection conn = new NpgsqlConnection(_conn);
                conn.Open();
                using NpgsqlCommand cmd = new NpgsqlCommand("select c_statusapproved from t_status where c_statusid=@c_statusid", conn);
                cmd.Parameters.AddWithValue("@c_statusid", id);
                cmd.CommandType = CommandType.Text;
                string statusApproved = (string)cmd.ExecuteScalar();
                if (statusApproved == "Issued")
                {
                    using NpgsqlCommand cmd2 = new NpgsqlCommand("update t_status set c_statusapproved=@c_statusapproved where c_statusid=@c_statusid  returning c_bookid", conn);
                    cmd2.Parameters.AddWithValue("@c_statusid", id);
                    cmd2.Parameters.AddWithValue("@c_statusapproved", "Approved");
                    cmd2.CommandType = CommandType.Text;
                    int cBookId = (int)cmd2.ExecuteScalar();
                    using NpgsqlCommand cmd3 = new NpgsqlCommand("update t_bookdetail set c_availstock=c_availstock-1 where c_bookid=@c_bookid", conn);
                    cmd3.Parameters.AddWithValue("@c_bookid", cBookId);
                    cmd3.ExecuteNonQuery();
                    return true;
                }
                else
                {
                    Console.WriteLine("The status is not Issued");
                    return false;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                return false;
            }
        }
        public bool Rejected(int id)
        {
            try
            {
                using NpgsqlConnection conn = new NpgsqlConnection(_conn);
                conn.Open();
                using NpgsqlCommand cmd = new NpgsqlCommand("select c_statusreturn from t_status where c_statusid=@c_statusid", conn);
                cmd.Parameters.AddWithValue("@c_statusid", id);
                cmd.CommandType = CommandType.Text;
                string statusReturn = (string)cmd.ExecuteScalar();
                if (statusReturn == "ForReturn")
                {
                    using NpgsqlCommand cmd2 = new NpgsqlCommand("update t_status set c_statusreturn=@c_statusreturn where c_statusid=@c_statusid  returning c_bookid", conn);
                    cmd2.Parameters.AddWithValue("@c_statusid", id);
                    cmd2.Parameters.AddWithValue("@c_statusreturn", "Return");
                    cmd2.CommandType = CommandType.Text;
                    int cBookId = (int)cmd2.ExecuteScalar();
                    using NpgsqlCommand cmd3 = new NpgsqlCommand("update t_bookdetail set c_availstock=c_availstock+1 where c_bookid=@c_bookid", conn);
                    cmd3.Parameters.AddWithValue("@c_bookid", cBookId);
                    cmd3.ExecuteNonQuery();
                    return true;
                }
                else
                {
                    Console.WriteLine("The status is not ForReturn");
                    return false;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                return false;
            }
        }



    }
}