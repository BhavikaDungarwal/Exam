using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Mvc.Models;
using Npgsql;

namespace Mvc.Repositories
{
    public class AuthRepository : IAuthRepository
    {
        private readonly string _conn;
        private readonly IHttpContextAccessor _httpContextAccessor;
        public AuthRepository(IConfiguration configuration, IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
            _conn = configuration.GetConnectionString("DefaultConnection");
        }
        public AuthModel Login(AuthModel auths)
        {
            try
            {
                using NpgsqlConnection conn = new NpgsqlConnection(_conn);
                conn.Open();
                using NpgsqlCommand cmd = new NpgsqlCommand("select * from t_auth where c_useremail=@email and c_password=@password", conn);
                cmd.Parameters.AddWithValue("@email", auths.c_useremail);
                cmd.Parameters.AddWithValue("@password", auths.c_password);
                cmd.CommandType = CommandType.Text;
                using (NpgsqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        var http = _httpContextAccessor.HttpContext;
                        http.Session.SetString("Email", auths.c_useremail);
                        AuthModel auth = new AuthModel
                        {
                            c_userid = Convert.ToInt16(reader["c_userid"]),
                            c_username = reader["c_username"].ToString(),
                            c_useremail = reader["c_useremail"].ToString(),
                            c_password = reader["c_password"].ToString(),
                        };
                        http.Session.SetInt32("Userid", auth.c_userid);
                        return auth;
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }

            return null;
        }

    }
}