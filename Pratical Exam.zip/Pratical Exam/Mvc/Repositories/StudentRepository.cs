using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Mvc.Models;
using Npgsql;

namespace Mvc.Repositories
{
    public class StudentRepository : IStudentRepository
    {
        private readonly string _conn;
        private readonly IHttpContextAccessor _httpContextAccessor;
        public StudentRepository(IConfiguration configuration, IHttpContextAccessor httpContextAccessor)
        {
            _conn = configuration.GetConnectionString("DefaultConnection");
            _httpContextAccessor = httpContextAccessor;
        }

        public StudentModel Login(StudentModel auths)
        {
            try
            {
                using NpgsqlConnection conn = new NpgsqlConnection(_conn);
                conn.Open();
                using NpgsqlCommand cmd = new NpgsqlCommand("select * from t_student where c_email=@email and c_password=@password", conn);
                cmd.Parameters.AddWithValue("@email", auths.c_email);
                cmd.Parameters.AddWithValue("@password", auths.c_password);
                cmd.CommandType = CommandType.Text;
                using (NpgsqlDataReader reader = cmd.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        var http = _httpContextAccessor.HttpContext;
                        http.Session.SetString("Email", auths.c_email);
                        StudentModel auth = new StudentModel
                        {
                            c_sid = Convert.ToInt32(reader["c_sid"]),
                            c_fname = reader["c_fname"].ToString(),
                            c_lname = reader["c_lname"].ToString(),
                            c_email = reader["c_email"].ToString(),
                        };
                        http.Session.SetInt32("Userid", auth.c_sid);
                        return auth;
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }

            return null;
        }


        public List<FieldModel> GetAllField()
        {
            List<FieldModel> fields = new List<FieldModel>();
            try
            {
                using NpgsqlConnection conn = new NpgsqlConnection(_conn);
                conn.Open();
                using (NpgsqlCommand cmd = new NpgsqlCommand("Select * from t_field", conn))
                using (NpgsqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        FieldModel field = new FieldModel
                        {
                            c_fid = Convert.ToInt32(reader["c_fid"]),
                            c_fieldname = reader["c_fieldname"].ToString()
                        };
                        fields.Add(field);
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            return fields;
        }

        public List<StudentModel> GetAllData()
        {
            List<StudentModel> datas = new List<StudentModel>();
            try
            {
                using NpgsqlConnection conn = new NpgsqlConnection(_conn);
                conn.Open();
                using (NpgsqlCommand cmd = new NpgsqlCommand("select k.c_sid, k.c_fname,k.c_lname, k.c_fid, k.c_gender, k.c_sphoto, k.c_phoneno,k.c_email, k.c_password, k.c_userid, c.c_fieldname, a.c_username from t_student k join t_field c on k.c_fid=c.c_fid join t_auth a on k.c_userid = a.c_userid", conn))
                {
                    using (NpgsqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            StudentModel data = new StudentModel
                            {
                                c_sid = Convert.ToInt32(reader["c_sid"]),
                                c_fname = reader["c_fname"].ToString(),
                                c_lname = reader["c_lname"].ToString(),
                                c_fid = Convert.ToInt32(reader["c_fid"]),
                                c_gender = reader["c_gender"].ToString(),
                                c_sphoto = reader["c_sphoto"].ToString(),
                                c_phoneno = Convert.ToDecimal(reader["c_phoneno"]),
                                c_email = reader["c_email"].ToString(),
                                c_password = reader["c_password"].ToString(),
                                c_fieldname = reader["c_fieldname"].ToString(),
                                c_userid = Convert.ToInt32(reader["c_userid"]),
                                c_username = reader["c_username"].ToString(),
                            };
                            datas.Add(data);
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            return datas;

        }

        public bool Insert(StudentModel stud)
        {
            try
            {
                var password = stud.c_fname + stud.c_phoneno;
                using NpgsqlConnection conn = new NpgsqlConnection(_conn);
                conn.Open();

                if (stud.c_phoneno != null && stud.c_phoneno is decimal)
                {
                    using NpgsqlCommand cmd = new NpgsqlCommand("INSERT INTO t_student (c_fname,c_lname, c_fid, c_gender, c_sphoto, c_phoneno, c_email,c_password,c_userid) VALUES (@c_fname,@c_lname, @c_fid, @c_gender, @c_sphoto, @c_phoneno, @c_email,@c_password,@c_userid)", conn);
                    cmd.Parameters.AddWithValue("@c_fname", stud.c_fname);
                    cmd.Parameters.AddWithValue("@c_lname", stud.c_lname);
                    cmd.Parameters.AddWithValue("@c_fid", stud.c_fid);
                    cmd.Parameters.AddWithValue("@c_gender", stud.c_gender);
                    cmd.Parameters.AddWithValue("@c_sphoto", stud.c_sphoto);
                    cmd.Parameters.AddWithValue("@c_phoneno", stud.c_phoneno);
                    cmd.Parameters.AddWithValue("@c_email", stud.c_email);
                    cmd.Parameters.AddWithValue("@c_password", password);
                    cmd.Parameters.AddWithValue("@c_userid", stud.c_userid);
                    cmd.CommandType = CommandType.Text;
                    cmd.ExecuteNonQuery();
                    return true;
                }
                else
                {
                    Console.WriteLine("c_phoneno is null or not a numeric value.");
                    return false;
                }
            }
            catch (Exception e)
            {
                Console.WriteLine("Error inserting data: " + e.Message);
                return false;
            }
        }

        public List<CategoryModel> GetAllCategory()
        {
            List<CategoryModel> categories = new List<CategoryModel>();
            try
            {
                using (NpgsqlConnection conn = new NpgsqlConnection(_conn))
                {
                    conn.Open();
                    using (NpgsqlCommand cmd = new NpgsqlCommand("Select * from t_category", conn))
                    {
                        using (NpgsqlDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                CategoryModel category = new CategoryModel
                                {
                                    c_catid = Convert.ToInt32(reader["c_catid"]),
                                    c_catname = reader["c_catname"].ToString()
                                };
                                categories.Add(category);
                            }
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            return categories;
        }
        public List<BookModel> GetAllBook(int catid)
        {
            List<BookModel> books = new List<BookModel>();
            try
            {
                using (NpgsqlConnection conn = new NpgsqlConnection(_conn))
                {
                    conn.Open();
                    using (NpgsqlCommand cmd = new NpgsqlCommand("Select * from t_bookdetail where c_catid = @catid", conn))
                    {
                        cmd.Parameters.AddWithValue("@catid", catid);
                        using (NpgsqlDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                BookModel book = new BookModel
                                {
                                    c_bookid = Convert.ToInt32(reader["c_bookid"]),
                                    c_bookname = reader["c_bookname"].ToString()
                                };
                                books.Add(book);
                            }
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            return books;
        }
        public List<BookModel> GetAllBooks()
        {
            List<BookModel> books = new List<BookModel>();
            try
            {
                using (NpgsqlConnection conn = new NpgsqlConnection(_conn))
                {
                    conn.Open();
                    using (NpgsqlCommand cmd = new NpgsqlCommand("Select * from t_bookdetail ", conn))
                    {
                        using (NpgsqlDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                BookModel book = new BookModel
                                {
                                    c_bookid = Convert.ToInt32(reader["c_bookid"]),
                                    c_bookname = reader["c_bookname"].ToString()
                                };
                                books.Add(book);
                            }
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            return books;
        }

        public bool StatusInsert(StatusModel stud)
        {
            try
            {
                using NpgsqlConnection conn = new NpgsqlConnection(_conn);
                conn.Open();

                using NpgsqlCommand cmd = new NpgsqlCommand("INSERT INTO t_status (c_sid,c_catid, c_bookid, c_date, c_statusapproved, c_statusreturn) VALUES (@c_sid,@c_catid, @c_bookid, @c_date, @c_statusapproved, @c_statusreturn)", conn);
                cmd.Parameters.AddWithValue("@c_sid", stud.c_sid);
                cmd.Parameters.AddWithValue("@c_catid", stud.c_catid);
                cmd.Parameters.AddWithValue("@c_bookid", stud.c_bookid);
                cmd.Parameters.AddWithValue("@c_date", stud.c_date);
                cmd.Parameters.AddWithValue("@c_statusapproved", "Issued");
                cmd.Parameters.AddWithValue("@c_statusreturn", "NotReturn");
                cmd.CommandType = CommandType.Text;
                cmd.ExecuteNonQuery();
                return true;
            }
            catch (Exception e)
            {
                Console.WriteLine("Error inserting data: " + e.Message);
                return false;
            }
        }

        public List<StatusModel> GetAllStatus()
        {
            List<StatusModel> status = new List<StatusModel>();
            try
            {
                using NpgsqlConnection conn = new NpgsqlConnection(_conn);
                conn.Open();
                var http = _httpContextAccessor.HttpContext;
                var sid = http.Session.GetInt32("Userid");
                using (NpgsqlCommand cmd = new NpgsqlCommand("Select t_status.c_statusid,t_status.c_sid,t_status.c_catid,t_status.c_statusreturn,t_status.c_statusapproved,t_status.c_bookid,t_status.c_date, t_category.c_catname,t_bookdetail.c_bookname from t_status join t_category on t_status.c_catid = t_category.c_catid join t_bookdetail on t_status.c_bookid = t_bookdetail.c_bookid where c_sid = @sid order by t_status.c_statusid ", conn))
                {
                    cmd.Parameters.AddWithValue("@sid", sid);
                    using (NpgsqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            StatusModel st = new StatusModel
                            {
                                c_statusid = Convert.ToInt32(reader["c_statusid"]),
                                c_sid = Convert.ToInt32(reader["c_sid"]),
                                c_catid = Convert.ToInt32(reader["c_catid"]),
                                c_bookid = Convert.ToInt32(reader["c_bookid"]),
                                c_date = Convert.ToDateTime(reader["c_date"]),
                                c_statusreturn = reader["c_statusreturn"].ToString(),
                                c_statusapproved = reader["c_statusapproved"].ToString(),
                                c_catname = reader["c_catname"].ToString(),
                                c_bookname = reader["c_bookname"].ToString(),
                            };
                            status.Add(st);
                        }
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            return status;
        }

       
        public bool Rejected(int id)
        {
            try
            {
                using (NpgsqlConnection conn = new NpgsqlConnection(_conn)){
                conn.Open();
                using NpgsqlCommand cmd = new NpgsqlCommand("update t_status set c_statusreturn=@c_statusreturn where c_statusid=@c_statusid", conn);
                cmd.Parameters.AddWithValue("@c_statusid", id);
                cmd.Parameters.AddWithValue("@c_statusreturn", "ForReturn");
                cmd.CommandType = CommandType.Text;
                cmd.ExecuteNonQuery();
                return true;
            }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                return false;
            }
        }

    }
}