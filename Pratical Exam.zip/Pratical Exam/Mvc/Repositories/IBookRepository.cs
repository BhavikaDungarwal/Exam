using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Mvc.Models;

namespace Mvc.Repositories
{
    public interface IBookRepository
    {
        void Delete(int id);
        List<CategoryModel> GetAllCategory();
        List<BookModel> GetAllData();
        bool Insert(BookModel book);
        void multidelete(List<int> ids);
        bool Update(BookModel book);
        List<StatusModel> GetAllStatus();
        bool Approved(int id);
        bool Rejected(int id);
    }
}