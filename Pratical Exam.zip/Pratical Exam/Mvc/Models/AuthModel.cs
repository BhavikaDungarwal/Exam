using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Mvc.Models
{
    public class AuthModel
    {
        public int c_userid { get; set; }
        public string c_username { get; set; }
        public string c_useremail { get; set; }
        public string c_password { get; set; }
    }
}