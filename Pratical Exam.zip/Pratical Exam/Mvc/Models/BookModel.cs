using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Mvc.Models
{
    public class BookModel
    {
        
        public int c_bookid { get; set; }
        public int c_catid { get; set; }
        public string c_bookname { get; set; }
        public int c_initialstock { get; set; }
        public int c_availstock { get; set; }
        public DateTime c_date { get; set; }
        public string c_catname { get; set; }
    }
}
    