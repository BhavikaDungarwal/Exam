using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Mvc.Models
{
    public class StudentModel
    {
        public int c_sid { get; set; }
        public string c_fname { get; set; }
        public string c_lname { get; set; }
        public string c_gender { get; set; }
        public string c_sphoto { get; set; }
        public int c_fid { get; set; }
        public decimal c_phoneno { get; set; }
        public string c_email { get; set; }
        public string c_password { get; set; }
        public string c_fieldname { get; set; }
        public int c_userid { get; set; }
        public string c_username { get; set; }
    }
}