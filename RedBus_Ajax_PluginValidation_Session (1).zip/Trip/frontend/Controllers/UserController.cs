using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using repositories.Interface;
using repositories.Models;

namespace frontend.Controllers
{
    public class UserController : Controller
    {
        private readonly ILogger<UserController> _logger;

        private IUserRepository _userRepository;

        public UserController(ILogger<UserController> logger, IUserRepository userRepository)
        {
            _logger = logger;
            _userRepository = userRepository;
        }

        public IActionResult Index()
        {
            var userEmail = HttpContext.Session.GetString("userEmail");
            TempData["userEmail"] = userEmail;
             var userId = HttpContext.Session.GetInt32("userId");
             TempData["userId"] = userId;
            return View();
        }
        public IActionResult getbookingdata()
        {
            var data = _userRepository.getAllData();
            return Json(data);
        }
        public IActionResult Add(BookingModel model)
        {
            model.c_status = "Departed";
            int newStock = model.c_currentstock - model.c_qty;
            var Booking = _userRepository.AddTrip(model,model.c_tripid, newStock);
            if (Booking)
            {
                    return Json(new { success = true });
            }
            return Json(new { success = false });
        }

         [HttpPost]
        public IActionResult CancelBooking(int id)
        {
            bool success = _userRepository.UpdateStatus(id, "Canceled");

            if (success)
            {
                return Ok("Booking canceled successfully.");
            }
            else
            {
                return BadRequest("Failed to cancel booking.");
            }
        }

        public IActionResult getParticularData(int id)
        {
            var data = _userRepository.getparticularData(id);

            return Json(data);
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View("Error!");
        }
    }
}