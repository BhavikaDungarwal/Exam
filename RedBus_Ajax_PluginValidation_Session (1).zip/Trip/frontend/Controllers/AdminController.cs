using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using repositories.Interface;
using repositories.Models;

namespace frontend.Controllers
{
    public class AdminController : Controller
    {
        private readonly ILogger<AdminController> _logger;

        private IAdminRepository _adminRepository;

        public AdminController(ILogger<AdminController> logger, IAdminRepository adminRepository)
        {
            _logger = logger;
            _adminRepository = adminRepository;
        }

        public IActionResult Index()
        {
            var userEmail = HttpContext.Session.GetString("userEmail");
            TempData["userEmail"] = userEmail;
            var userId = HttpContext.Session.GetInt32("userId");
            TempData["userId"] = userId;
            return View();
        }

        public IActionResult Add(TripModel model)
        {
            _adminRepository.AddTrip(model);

            return Json(new { success = true });
        }
        public IActionResult Update(TripModel model)
        {
            _adminRepository.UpdateTrip(model);

            return Json(new { success = true });
        }
        public IActionResult AdGetAllTrip()
        {
            var data = _adminRepository.GetAllTrips();

            return Json(data);
        }
        public IActionResult gettourdata()
        {
            var data = _adminRepository.getAllData();

            return Json(data);
        }
        public IActionResult getParticularData(int id)
        {
            var data = _adminRepository.getparticularData(id);

            return Json(data);
        }
        public IActionResult Delete(int id)
        {
            var data = _adminRepository.DeleteTrip(id);

            return Json(data);
        }



        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View("Error!");
        }
    }
}