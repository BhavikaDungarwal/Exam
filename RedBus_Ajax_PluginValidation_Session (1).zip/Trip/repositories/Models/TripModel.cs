using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace repositories.Models
{
    public class TripModel
    {
        public int c_tripid { get; set; }
        public int c_aid { get; set; }
        public int c_ticketprice { get; set; }
        public int c_ticketstock { get; set; }
        public int c_currentstock { get; set; }
        public int c_userid { get; set; }
        public string c_tripname { get; set; }
    }
}