using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace repositories.Models
{
    public class TripsModel
    {
        public int c_aid { get; set; }
        public string c_tripname { get; set; }
    }
}