using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using repositories.Models;

namespace repositories.Interface
{
    public interface IUserRepository
    {
        bool AddTrip(BookingModel model,int tripId, int newStock);
        TripModel getparticularData(int id);

        List<BookingModel> getAllData();
        bool UpdateStatus(int id, string status);
    }
}