using System.Data;
using Microsoft.Extensions.Configuration;
using Npgsql;
using Repositories.Interface;
using Repositories.Models;

namespace Repositories.Implementation
{
    public class AuthRepository : IAuthRepository
    {
        private readonly string _con;

        public AuthRepository(IConfiguration configuration)
        {
            _con = configuration.GetConnectionString("DefaultConnection");
        }
        public authmodel login(authmodel model)
        {
            using (NpgsqlConnection con = new NpgsqlConnection(_con))
            {
                try
                {
                    con.Open();
                    string query = "SELECT * FROM t_auth WHERE c_email = @c_email AND c_password = @c_password";
                    using (NpgsqlCommand cmd = new NpgsqlCommand(query, con))
                    {
                        cmd.CommandType = CommandType.Text;
                        cmd.Parameters.AddWithValue("@c_email", model.c_email);
                        cmd.Parameters.AddWithValue("@c_password", model.c_password);
                        using (NpgsqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                authmodel data = new authmodel
                                {
                                    c_userid = reader.GetInt32(0),
                                    c_name = reader.GetString(1),
                                    c_email = reader.GetString(2),
                                    c_password = reader.GetString(3),
                                    c_role = reader.GetInt16(4)
                                };
                                return data;
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                return null;
            }
        }



       
    }
}