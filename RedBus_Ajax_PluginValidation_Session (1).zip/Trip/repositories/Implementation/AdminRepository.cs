using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Npgsql;
using repositories.Interface;
using repositories.Models;

namespace repositories.Implementation
{
    public class AdminRepository : IAdminRepository
    {
        private readonly string _con;
        private IHttpContextAccessor httpContextAccessor;
        public AdminRepository(IConfiguration configuration, IHttpContextAccessor httpContext)
        {
            _con = configuration.GetConnectionString("DefaultConnection");
            httpContextAccessor = httpContext;
        }
        public bool AddTrip(TripModel model)
        {

            using (NpgsqlConnection con = new NpgsqlConnection(_con))
            {
                try
                {
                    con.Open();
                    string query = "INSERT INTO t_tripadmin VALUES(DEFAULT,@c_aid,@c_ticketprice,@c_ticketstock,@c_currentstock,@c_userid)";
                    using (NpgsqlCommand cmd = new NpgsqlCommand(query, con))
                    {

                        cmd.Parameters.AddWithValue("@c_aid", model.c_aid);
                        cmd.Parameters.AddWithValue("@c_ticketprice", model.c_ticketprice);
                        cmd.Parameters.AddWithValue("@c_ticketstock", model.c_ticketstock);
                        cmd.Parameters.AddWithValue("@c_currentstock", model.c_currentstock);
                        cmd.Parameters.AddWithValue("@c_userid", model.c_userid);
                        cmd.CommandType = CommandType.Text;
                        cmd.ExecuteNonQuery();
                        return true;
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    return false;
                }
            }
        }

        public bool DeleteTrip(int id)
        {
            using (NpgsqlConnection con = new NpgsqlConnection(_con))
            {
                try
                {
                    con.Open();
                    string query = "DELETE FROM t_tripadmin WHERE c_tripid=@id";
                    using (NpgsqlCommand cmd = new NpgsqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@id", id);
                        cmd.CommandType = CommandType.Text;
                        cmd.ExecuteNonQuery();
                        return true;
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    return false;
                }
            }
        }

        public List<TripModel> getAllData()
        {
            List<TripModel> data = new List<TripModel>();
            using (NpgsqlConnection con = new NpgsqlConnection(_con))
            {
                con.Open();
                int? userID = httpContextAccessor.HttpContext.Session.GetInt32("userId");
                // string query2 = "SELECT * FROM t_tripadmin WHERE c_userid=@uid";
                string query1 = "SELECT t.c_tripid, t.c_aid, t.c_ticketprice, t.c_ticketstock, t.c_currentstock, a.c_tripname FROM t_tripadmin t JOIN t_addtrip a ON t.c_aid = a.c_aid WHERE t.c_userid=@uid";
                using (NpgsqlCommand cmd = new NpgsqlCommand(query1, con))
                {
                    cmd.Parameters.AddWithValue("uid", userID);
                    NpgsqlDataReader dr = cmd.ExecuteReader();
                    while (dr.Read())
                    {
                        TripModel dm = new TripModel()
                        {
                            c_tripid = Convert.ToInt32(dr["c_tripid"]),
                            c_aid = Convert.ToInt32(dr["c_aid"]),
                            c_ticketprice = Convert.ToInt32(dr["c_ticketprice"]),
                            c_ticketstock = Convert.ToInt32(dr["c_ticketstock"]),
                            c_currentstock = Convert.ToInt32(dr["c_currentstock"]),
                            c_tripname = Convert.ToString(dr["c_tripname"])
                        };
                        data.Add(dm);
                        }
                        return data;
                }
            }
        }

        public List<TripsModel> GetAllTrips()
        {
            using (NpgsqlConnection con = new NpgsqlConnection(_con))
            {
                try
                {
                    con.Open();
                    string query = "SELECT * FROM t_addtrip";
                    using (NpgsqlCommand cmd = new NpgsqlCommand(query, con))
                    {
                        cmd.CommandType = CommandType.Text;
                        using (NpgsqlDataReader reader = cmd.ExecuteReader())
                        {
                            List<TripsModel> data = new List<TripsModel>();
                            while (reader.Read())
                            {
                                TripsModel model = new TripsModel
                                {
                                    c_aid = reader.GetInt16(0),
                                    c_tripname = reader.GetString(1)
                                };
                                data.Add(model);
                            }
                            return data;
                        }
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    return null;
                }
            }
        }

        public TripModel getparticularData(int id)
        {
            using (NpgsqlConnection con = new NpgsqlConnection(_con)){
                try{
                    con.Open();
                    string query = "SELECT * FROM t_tripadmin WHERE c_tripid=@id";
                    using (NpgsqlCommand cmd = new NpgsqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@id", id);
                        cmd.CommandType = CommandType.Text;
                        using (NpgsqlDataReader reader = cmd.ExecuteReader())
                        {
                            TripModel model = new TripModel();
                            while (reader.Read())
                            {
                                model.c_tripid = reader.GetInt32(0);
                                model.c_aid = reader.GetInt32(1);
                                model.c_ticketprice = reader.GetInt32(2);
                                model.c_ticketstock = reader.GetInt32(3);
                                model.c_currentstock = reader.GetInt32(4);
                                model.c_userid = reader.GetInt32(5);
                            }
                            return model;
                        }
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    return null;
                }
            }
        }

        public bool UpdateTrip(TripModel model)
        {
            using (NpgsqlConnection con = new NpgsqlConnection(_con))
            { 
                try{
                    con.Open();
                    string query = "UPDATE t_tripadmin SET c_aid=@c_aid,c_ticketprice=@c_ticketprice,c_ticketstock=@c_ticketstock,c_currentstock=@c_currentstock WHERE c_tripid=@c_tripid";
                    using (NpgsqlCommand cmd = new NpgsqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@c_aid", model.c_aid);
                        cmd.Parameters.AddWithValue("@c_ticketprice", model.c_ticketprice);
                        cmd.Parameters.AddWithValue("@c_ticketstock", model.c_ticketstock);
                        cmd.Parameters.AddWithValue("@c_currentstock", model.c_currentstock);
                        cmd.Parameters.AddWithValue("@c_tripid", model.c_tripid);
                        cmd.CommandType = CommandType.Text;
                        cmd.ExecuteNonQuery();
                        return true;
                    }
                }
                catch(Exception ex){
                    Console.WriteLine(ex.Message);
                    return false;
                }
            }
        }
    }
}