using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Npgsql;
using repositories.Interface;
using repositories.Models;

namespace repositories.Implementation
{
    public class UserRepository : IUserRepository
    {
        private readonly string _con;
        private IHttpContextAccessor httpContextAccessor;
        public UserRepository(IConfiguration configuration, IHttpContextAccessor httpContext)
        {
            _con = configuration.GetConnectionString("DefaultConnection");
            httpContextAccessor = httpContext;
        }
        public bool AddTrip(BookingModel model, int tripId, int newStock)
        {
            using (NpgsqlConnection con = new NpgsqlConnection(_con))
            {
                try
                {
                    con.Open();
                    string updateQuery = "UPDATE t_tripadmin SET c_currentstock = @newStock WHERE c_tripid = @tripId";
                    using (NpgsqlCommand cmmd = new NpgsqlCommand(updateQuery, con))
                    {
                        cmmd.Parameters.AddWithValue("@newStock", newStock);
                        cmmd.Parameters.AddWithValue("@tripId", tripId);
                        cmmd.ExecuteNonQuery();
                    }
                    string query1 = "INSERT INTO t_booktripuser (c_aid, c_bookdate, c_ticketprice, c_currentstock, c_qty, c_totalcost, c_status,c_userid) VALUES (@c_aid, @c_bookdate, @c_ticketprice, @c_currentstock, @c_qty, @c_totalcost, @c_status,@c_userid)";
                    using (NpgsqlCommand cmd = new NpgsqlCommand(query1, con))
                    {
                        cmd.Parameters.AddWithValue("@c_aid", model.c_aid);
                        cmd.Parameters.AddWithValue("@c_bookdate", model.c_bookdate);
                        cmd.Parameters.AddWithValue("@c_ticketprice", model.c_ticketprice);
                        cmd.Parameters.AddWithValue("@c_currentstock", model.c_currentstock);
                        cmd.Parameters.AddWithValue("@c_qty", model.c_qty);
                        cmd.Parameters.AddWithValue("@c_totalcost", model.c_totalcost);
                        cmd.Parameters.AddWithValue("@c_status", model.c_status);
                        cmd.Parameters.AddWithValue("@c_userid", model.c_userid);
                        cmd.ExecuteNonQuery();

                        return true;
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    return false;
                }
            }
        }

        public List<BookingModel> getAllData()
        {
            List<BookingModel> data = new List<BookingModel>();
            using (NpgsqlConnection con = new NpgsqlConnection(_con))
            {
                con.Open();
                int? userID = httpContextAccessor.HttpContext.Session.GetInt32("userId");
                string query = "SELECT bt.c_bookid, bt.c_aid, bt.c_bookdate, bt.c_ticketprice, bt.c_currentstock, bt.c_qty, bt.c_totalcost, bt.c_status, bt.c_userid, at.c_tripname FROM t_booktripuser bt JOIN t_addtrip at ON bt.c_aid = at.c_aid WHERE bt.c_userid = @uid AND bt.c_status != 'Canceled'";

                string query1 = "SELECT bt.c_bookid, bt.c_aid, bt.c_bookdate, bt.c_ticketprice, bt.c_currentstock, bt.c_qty, bt.c_totalcost, bt.c_status, bt.c_userid, at.c_tripname FROM t_booktripuser bt JOIN t_addtrip at ON bt.c_aid = at.c_aid WHERE bt.c_userid = @uid ";
                using (NpgsqlCommand cmd = new NpgsqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@uid", userID);
                    using (NpgsqlDataReader dr = cmd.ExecuteReader())
                    {
                        while (dr.Read())
                        {
                            BookingModel dm = new BookingModel()
                            {
                                c_bookid = Convert.ToInt32(dr["c_bookid"]),
                                c_aid = Convert.ToInt32(dr["c_aid"]),
                                c_bookdate = Convert.ToDateTime(dr["c_bookdate"]),
                                c_ticketprice = Convert.ToInt32(dr["c_ticketprice"]),
                                c_currentstock = Convert.ToInt32(dr["c_currentstock"]),
                                c_qty = Convert.ToInt32(dr["c_qty"]),
                                c_totalcost = Convert.ToInt32(dr["c_totalcost"]),
                                c_tripname = Convert.ToString(dr["c_tripname"]),
                                c_userid = Convert.ToInt16(dr["c_userid"]),
                            };

                            if ((dm.c_bookdate.Date == DateTime.Today || dm.c_bookdate.Date == DateTime.Today.AddDays(1)) && dm.c_status != "Canceled")
                            {
                                dm.c_status = "Scheduled";
                            }
                            else if (dm.c_bookdate.Date > DateTime.Today && dm.c_status != "Canceled")
                            {
                                dm.c_status = "Departed";
                            }
                            else
                            {
                                dm.c_status = "Canceled";
                            }

                            UpdateStatusdata(dm.c_bookid, dm.c_status);

                            data.Add(dm);
                        }
                    }
                }
            }
            return data;
        }

        private void UpdateStatusdata(int bookId, string status)
        {
            using (NpgsqlConnection con = new NpgsqlConnection(_con))
            {
                con.Open();
                string updateQuery = "UPDATE t_booktripuser SET c_status = @status WHERE c_bookid = @bookId";
                using (NpgsqlCommand cmd = new NpgsqlCommand(updateQuery, con))
                {
                    cmd.Parameters.AddWithValue("@status", status);
                    cmd.Parameters.AddWithValue("@bookId", bookId);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public TripModel getparticularData(int id)
        {
            using (NpgsqlConnection con = new NpgsqlConnection(_con))
            {
                try
                {
                    con.Open();
                    string query = "SELECT * FROM t_tripadmin WHERE c_aid=@id";
                    using (NpgsqlCommand cmd = new NpgsqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@id", id);
                        cmd.CommandType = CommandType.Text;
                        using (NpgsqlDataReader reader = cmd.ExecuteReader())
                        {
                            TripModel model = new TripModel();
                            while (reader.Read())
                            {
                                model.c_tripid = reader.GetInt32(0);
                                model.c_aid = reader.GetInt32(1);
                                model.c_ticketprice = reader.GetInt32(2);
                                model.c_ticketstock = reader.GetInt32(3);
                                model.c_currentstock = reader.GetInt32(4);
                                model.c_userid = reader.GetInt32(5);
                            }
                            return model;
                        }
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    return null;
                }
            }
        }

        public bool UpdateStatus(int id, string status)
        {
            try
            {
                using (NpgsqlConnection con = new NpgsqlConnection(_con))
                {
                    con.Open();
                    string query = "UPDATE t_booktripuser SET c_status=@status WHERE c_bookid=@id";
                    using (NpgsqlCommand cmd = new NpgsqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@status", status);
                        cmd.Parameters.AddWithValue("@id", id);
                        cmd.CommandType = CommandType.Text;
                        cmd.ExecuteNonQuery();
                        return true;
                    }
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                return false;
            }
        }
    }
}