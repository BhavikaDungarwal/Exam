using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using ShoppingCart.Models;
using ShoppingCart.Repository;

namespace ShoppingCart.Controllers
{
    public class UserController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        protected IUserRepository _userRepository;

        public UserController(ILogger<HomeController> logger, IUserRepository userRepository)
        {
            _logger = logger;
            _userRepository =userRepository;
        }

        [HttpGet]
        public IActionResult Index()
        {
            string? userEmail = HttpContext.Session.GetString("c_email");
            TempData["userEmail"] = userEmail;

            return View();
        }

        [HttpGet]
        public IActionResult GetAllData()
        {
         var itemDetails = _userRepository.GetItemDetails();
            return Json(itemDetails);
        }

        [HttpGet]
        public IActionResult GetItemDetails(int id)
        {
            try
            {
                var item = _userRepository.GetItemById(id);
                return Json(item);
            }
            catch (Exception ex)
            {
                return StatusCode(500, "An error occurred while fetching item details.");
            }
        }

        [HttpPost]
public IActionResult PurchaseItem(int customerId, int itemId, int quantity, int totalCost)
{
    try
    {
            int? userId = HttpContext.Session.GetInt32("c_userid");
        _userRepository.AddPurchase(userId.Value, itemId, quantity, totalCost);
        
        return Ok("Purchase added successfully!");
    }
    catch (Exception ex)
    {
        return StatusCode(500, "An error occurred while adding the purchase.");
    }
}

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}