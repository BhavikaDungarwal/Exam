using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using ShoppingCart.Models;
using ShoppingCart.Repository;

namespace ShoppingCart.Controllers
{
    public class AdminController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        private IAdminRepository _adminRepository;

        private IWebHostEnvironment _hostEnvironment;

        public AdminController(ILogger<HomeController> logger, IAdminRepository adminRepository, IWebHostEnvironment hostEnvironment)
        {
            _logger = logger;
            _adminRepository = adminRepository;
            _hostEnvironment = hostEnvironment;
        }

        [HttpGet]
        public IActionResult Index()
        {
            string? userEmail = HttpContext.Session.GetString("c_email");
            TempData["userEmail"] = userEmail;
            return View();
        }

        [HttpGet]
        public IActionResult GetAllData()
        {
            var items = _adminRepository.fetchItem();
            return Json(items);
        }

        [HttpGet]
        public IActionResult GetAllCategories()
        {
            var categories = _adminRepository.FetchCategories();
            return Json(categories);
        }
        [HttpGet]
        public IActionResult GetAllCategory(int id)
        {
            var category = _adminRepository.GetCategoryById(id);
            if (category == null)
            {
                return NotFound();
            }
            return Json(category);
        }

        [HttpGet]
        public IActionResult AddItem()
        {
            return View();
        }

        [HttpPost]
        public IActionResult AddItem(itemModel item, IFormFile image)
        {
            if (image != null && image.Length > 0)
            {
                string filename = Guid.NewGuid().ToString() + Path.GetExtension(image.FileName);
                var filePath = Path.Combine(_hostEnvironment.WebRootPath, "Photos", filename);

                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    image.CopyTo(stream);
                }

                item.c_image = filename;
            }

            bool success = _adminRepository.addItem(item);
            if (success)
            {
                return Json(new { success = true });
            }
            else
            {
                return Json(new { success = false });
            }
        }
        [HttpGet]
        public IActionResult GetItemDetails(int id)
        {
            var item = _adminRepository.GetItemById(id);
            if (item == null)
            {
                return NotFound();
            }
            return Json(item);
        }

        [HttpPost]
        public IActionResult EditItem(itemModel item, IFormFile? image)
        {

            if (image != null)
            {
                string filename = Guid.NewGuid().ToString() + Path.GetExtension(image.FileName);
                var filePath = Path.Combine(_hostEnvironment.WebRootPath, "Photos", filename);

                using (var stream = new FileStream(filePath, FileMode.Create))
                {
                    image.CopyTo(stream);
                }
                item.c_image = filename;
            }
            else
            {
                var exist = _adminRepository.GetItemById(item.c_itemid);
                item.c_image = exist.c_image;
            }
            if (_adminRepository.UpdateItem(item))
            {
                return Json(new { success = true });
            }
            else
            {
                return Json(new { success = false });

            }
        }


        [HttpPost]
        public IActionResult DeleteItem(int itemId)
        {
            if (_adminRepository.DeleteItem(itemId))
            {
                return RedirectToAction("Index");
            }
            return NotFound();
        }


        [HttpGet]
        public IActionResult GetPurchaseData()
        {
            List<purchaseModel> purchases = _adminRepository.FetchPurchaseData();
            return Json(purchases);
        }




        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}