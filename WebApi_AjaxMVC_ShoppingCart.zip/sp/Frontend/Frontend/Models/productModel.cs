using System;

namespace ShoppingCart.Models
{
    public class purchaseModel
    {
        public int c_purchaseid { get; set; }
        public int c_customerid { get; set; }
        public int c_itemid { get; set; }
        public int c_quantity { get; set; }
        public int c_totalcost { get; set; }
        public DateTime c_purchasedate { get; set; }

        //for item name and image
        public string c_itemname { get; set; }

        public string c_image { get; set; }

        //for user name

        public int c_userid { get; set; }

        public string c_name { get; set; }
    }
}