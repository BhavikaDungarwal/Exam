using System.ComponentModel.DataAnnotations;

namespace ShoppingCart.Models
{
    public class itemModel
    {
        public int c_itemid { get; set; }

    public string c_itemname { get; set; }

    public int c_categoryid { get; set; }

    public string c_image { get; set; }

    public int c_cost { get; set; }

    public int c_initialstock { get; set; }

    public int c_availablestock { get; set; }
    }
}