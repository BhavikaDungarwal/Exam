using ShoppingCart.Models;

namespace ShoppingCart.Repository
{
    public interface IUserRepository
    {
         List<itemModel> GetItemDetails();

         itemModel GetItemById(int id);
         void AddPurchase(int customerId, int itemId, int quantity, int totalCost);
    }
}