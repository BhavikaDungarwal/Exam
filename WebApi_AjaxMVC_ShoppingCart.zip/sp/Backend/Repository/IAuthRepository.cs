using ShoppingCart.Models;

namespace ShoppingCart.Repository
{
    public interface IAuthRepository
    {
        bool signup(authModel auth);
         authModel login(authModel auth);
    }
}