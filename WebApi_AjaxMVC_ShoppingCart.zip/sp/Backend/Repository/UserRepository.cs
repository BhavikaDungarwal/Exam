using Npgsql;
using ShoppingCart.Models;

namespace ShoppingCart.Repository
{
    public class UserRepository : IUserRepository
    {
        private readonly string _conn;

        public UserRepository(string conn)
        {
            _conn = conn;
        }

        public List<itemModel> GetItemDetails()
        {
            List<itemModel> items = new List<itemModel>();

            using (NpgsqlConnection conn = new NpgsqlConnection(_conn))
            {
                try
                {
                    conn.Open();
                    string query = "SELECT c_itemid, c_itemname, c_image, c_cost FROM t_item";
                    using (NpgsqlCommand cmd = new NpgsqlCommand(query, conn))
                    {
                        using (NpgsqlDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                itemModel item = new itemModel
                                {
                                    c_itemid = Convert.ToInt32(reader["c_itemid"]),
                                    c_itemname = reader["c_itemname"].ToString(),
                                    c_image = reader["c_image"].ToString(),
                                    c_cost = Convert.ToInt32(reader["c_cost"])
                                };
                                items.Add(item);
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
            return items;
        }

        public itemModel GetItemById(int id)
        {
            itemModel item = null;

            using (NpgsqlConnection conn = new NpgsqlConnection(_conn))
            {
                try
                {
                    conn.Open();
                    string query = "SELECT c_itemid, c_itemname, c_image, c_cost FROM t_item WHERE c_itemid = @ItemId";
                    using (NpgsqlCommand cmd = new NpgsqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@ItemId", id);
                        using (NpgsqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                item = new itemModel
                                {
                                    c_itemid = Convert.ToInt32(reader["c_itemid"]),
                                    c_itemname = reader["c_itemname"].ToString(),
                                    c_image = reader["c_image"].ToString(),
                                    c_cost = Convert.ToInt32(reader["c_cost"])
                                };
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
            return item;
        }

       public void AddPurchase(int customerId, int itemId, int quantity, int totalCost)
{
    using (NpgsqlConnection conn = new NpgsqlConnection(_conn))
    {
        try
        {
            conn.Open();
            
            string query = "INSERT INTO t_purchase (c_customerid, c_itemid, c_quantity, c_totalcost, c_purchasedate) VALUES (@CustomerId, @ItemId, @Quantity, @TotalCost, @PurchaseDate)";
            
            using (NpgsqlCommand cmd = new NpgsqlCommand(query, conn))
            {
                cmd.Parameters.AddWithValue("@CustomerId", customerId);
                cmd.Parameters.AddWithValue("@ItemId", itemId);
                cmd.Parameters.AddWithValue("@Quantity", quantity);
                cmd.Parameters.AddWithValue("@TotalCost", totalCost);
                cmd.Parameters.AddWithValue("@PurchaseDate", DateTime.Now);

                int rowsAffected = cmd.ExecuteNonQuery();

                if (rowsAffected == 1)
                {
                    Console.WriteLine("Purchase added successfully!");
                }
                else
                {
                    Console.WriteLine("Failed to add purchase.");
                }
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine("An error occurred: " + ex.Message);
            // Handle the exception as needed
        }
    }
}


    }
}