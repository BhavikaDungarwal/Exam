using Npgsql;
using ShoppingCart.Models;

namespace ShoppingCart.Repository
{
    public class AdminRepository : IAdminRepository
    {
        private readonly string _conn;

        public AdminRepository(string conn)
        {
            _conn = conn;
        }

        public List<itemModel> fetchItem()
        {
            List<itemModel> items = new List<itemModel>();

            using (NpgsqlConnection conn = new NpgsqlConnection(_conn))
            {
                try
                {
                    conn.Open();
                    string query = "SELECT * FROM t_item";
                    using (NpgsqlCommand cmd = new NpgsqlCommand(query, conn))
                    {
                        using (NpgsqlDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                itemModel item = new itemModel
                                {
                                    c_itemid = Convert.ToInt32(reader["c_itemid"]),
                                    c_itemname = reader["c_itemname"].ToString(),
                                    c_categoryid = Convert.ToInt32(reader["c_categoryid"]),
                                    c_image = reader["c_image"].ToString(),
                                    c_cost = Convert.ToInt32(reader["c_cost"]),
                                    c_initialstock = Convert.ToInt32(reader["c_initialstock"]),
                                    c_availablestock = Convert.ToInt32(reader["c_availablestock"])
                                };
                                items.Add(item);
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
            return items;
        }


        public bool addItem(itemModel item)
        {
            using (NpgsqlConnection conn = new NpgsqlConnection(_conn))
            {
                try
                {
                    conn.Open();
                    string query = "INSERT INTO t_item (c_itemname, c_categoryid, c_image, c_cost, c_initialstock, c_availablestock) VALUES (@c_itemname, @c_categoryid, @c_image, @c_cost, @c_initialstock, @c_availablestock)";
                    using (NpgsqlCommand cmd = new NpgsqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@c_itemname", item.c_itemname);
                        cmd.Parameters.AddWithValue("@c_categoryid", item.c_categoryid);
                        cmd.Parameters.AddWithValue("@c_image", item.c_image);
                        cmd.Parameters.AddWithValue("@c_cost", item.c_cost);
                        cmd.Parameters.AddWithValue("@c_initialstock", item.c_initialstock);
                        cmd.Parameters.AddWithValue("@c_availablestock", item.c_availablestock);

                        cmd.ExecuteNonQuery();
                    }
                    return true;
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    return false;
                }
            }
        }

        public List<categoryModel> FetchCategories()
        {
            List<categoryModel> categories = new List<categoryModel>();

            using (NpgsqlConnection conn = new NpgsqlConnection(_conn))
            {
                try
                {
                    conn.Open();
                    string query = "SELECT * FROM t_category";
                    using (NpgsqlCommand cmd = new NpgsqlCommand(query, conn))
                    {
                        using (NpgsqlDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                categoryModel category = new categoryModel
                                {
                                    c_categoryid = Convert.ToInt32(reader["c_categoryid"]),
                                    c_categoryname = reader["c_categoryname"].ToString()
                                };
                                categories.Add(category);
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
            return categories;
        }


        public itemModel GetItemById(int itemId)
        {
            itemModel item = null;

            using (NpgsqlConnection conn = new NpgsqlConnection(_conn))
            {
                try
                {
                    conn.Open();
                    string query = "SELECT * FROM t_item WHERE c_itemid = @itemId";
                    using (NpgsqlCommand cmd = new NpgsqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@itemId", itemId);
                        using (NpgsqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                item = new itemModel
                                {
                                    c_itemid = Convert.ToInt32(reader["c_itemid"]),
                                    c_itemname = reader["c_itemname"].ToString(),
                                    c_categoryid = Convert.ToInt32(reader["c_categoryid"]),
                                    c_image = reader["c_image"].ToString(),
                                    c_cost = Convert.ToInt32(reader["c_cost"]),
                                    c_initialstock = Convert.ToInt32(reader["c_initialstock"]),
                                    c_availablestock = Convert.ToInt32(reader["c_availablestock"])
                                };
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }

            return item;
        }

        public bool UpdateItem(itemModel item)
        {
            using (NpgsqlConnection conn = new NpgsqlConnection(_conn))
            {
                try
                {
                    conn.Open();
                    string query = "UPDATE t_item SET c_itemname = @c_itemname,c_categoryid = @c_categoryid, c_image = @c_image,c_cost = @c_cost, c_initialstock = @c_initialstock,c_availablestock = @c_availablestock WHERE c_itemid = @c_itemid";
                    using (NpgsqlCommand cmd = new NpgsqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@c_itemid", item.c_itemid);
                        cmd.Parameters.AddWithValue("@c_itemname", item.c_itemname);
                        cmd.Parameters.AddWithValue("@c_categoryid", item.c_categoryid);
                        cmd.Parameters.AddWithValue("@c_image", item.c_image);
                        cmd.Parameters.AddWithValue("@c_cost", item.c_cost);
                        cmd.Parameters.AddWithValue("@c_initialstock", item.c_initialstock);
                        cmd.Parameters.AddWithValue("@c_availablestock", item.c_availablestock);

                        cmd.ExecuteNonQuery();
                    }
                    return true;
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    return false;
                }
            }
        }

        public bool DeleteItem(int itemId)
        {
            using (NpgsqlConnection conn = new NpgsqlConnection(_conn))
            {
                try
                {
                    conn.Open();
                    string query = "DELETE FROM t_item WHERE c_itemid = @itemId";
                    using (NpgsqlCommand cmd = new NpgsqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@itemId", itemId);
                        cmd.ExecuteNonQuery();
                    }
                    return true;
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    return false;
                }
            }
        }

        public categoryModel GetCategoryById(int categoryId)
        {
            categoryModel category = null;

            using (NpgsqlConnection conn = new NpgsqlConnection(_conn))
            {
                try
                {
                    conn.Open();
                    string query = "SELECT * FROM t_category WHERE c_categoryid = @categoryId";
                    using (NpgsqlCommand cmd = new NpgsqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@categoryId", categoryId);
                        using (NpgsqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                category = new categoryModel
                                {
                                    c_categoryid = Convert.ToInt32(reader["c_categoryid"]),
                                    c_categoryname = reader["c_categoryname"].ToString()
                                };
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }

            return category;
        }

        public List<purchaseModel> FetchPurchaseData()
        {
            List<purchaseModel> purchases = new List<purchaseModel>();

            using (NpgsqlConnection conn = new NpgsqlConnection(_conn))
            {
                try
                {
                    conn.Open();
                    string query = "SELECT * FROM t_purchase";
                    using (NpgsqlCommand cmd = new NpgsqlCommand(query, conn))
                    {
                        using (NpgsqlDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                purchaseModel purchase = new purchaseModel
                                {
                                    c_purchaseid = Convert.ToInt32(reader["c_purchaseid"]),
                                    c_customerid = Convert.ToInt32(reader["c_customerid"]),
                                    c_itemid = Convert.ToInt32(reader["c_itemid"]),
                                    c_quantity = Convert.ToInt32(reader["c_quantity"]),
                                    c_totalcost = Convert.ToInt32(reader["c_totalcost"]),
                                    c_purchasedate = Convert.ToDateTime(reader["c_purchasedate"])
                                };
                                purchases.Add(purchase);
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
            return purchases;
        }


    }
}