using ShoppingCart.Models;

namespace ShoppingCart.Repository
{
    public interface IAdminRepository
    {
          bool addItem(itemModel auth);
         List<itemModel> fetchItem();
          List<categoryModel> FetchCategories();
          bool DeleteItem(int itemId);
          bool UpdateItem(itemModel item);
          itemModel GetItemById(int itemId);
          categoryModel GetCategoryById(int categoryId);
          List<purchaseModel> FetchPurchaseData();
    }
}