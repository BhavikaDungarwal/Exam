// AdminApiController.cs

using Microsoft.AspNetCore.Mvc;
using ShoppingCart.Models;
using ShoppingCart.Repository;
using System;

namespace Backend.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AdminApiController : ControllerBase
    {
        private readonly IAdminRepository _adminRepository;

        public AdminApiController(IAdminRepository adminRepository)
        {
            _adminRepository = adminRepository ?? throw new ArgumentNullException(nameof(adminRepository));
        }

        [HttpGet("fetchItems")]
        public IActionResult FetchItems()
        {
            try
            {
                var items = _adminRepository.fetchItem();
                return Ok(items);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"An error occurred while fetching items: {ex.Message}");
            }
        }

        [HttpPost("addItems")]
        public IActionResult AddItems(itemModel item)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                if (_adminRepository.addItem(item))
                {
                    return Ok("Item added successfully");
                }
                else
                {
                    return StatusCode(500, "Error occurred while adding item");
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"An error occurred while adding item: {ex.Message}");
            }
        }

        [HttpGet("fetchPurchaseData")]
        public IActionResult FetchPurchaseDatas()
        {
            try
            {
                var purchases = _adminRepository.FetchPurchaseData();
                return Ok(purchases);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"An error occurred while fetching purchase data: {ex.Message}");
            }
        }

         [HttpGet("getItem/{itemId}")]
        public IActionResult GetItemByIds(int itemId)
        {
            try
            {
                var item = _adminRepository.GetItemById(itemId);
                if (item != null)
                {
                    return Ok(item);
                }
                else
                {
                    return NotFound($"Item with ID {itemId} not found");
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"An error occurred while fetching item: {ex.Message}");
            }
        }

        [HttpPut("updateItem")]
        public IActionResult UpdateItems(itemModel item)
        {
            try
            {
                if (_adminRepository.UpdateItem(item))
                {
                    return Ok("Item updated successfully");
                }
                else
                {
                    return StatusCode(500, "Error occurred while updating item");
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"An error occurred while updating item: {ex.Message}");
            }
        }

        [HttpDelete("deleteItem/{itemId}")]
        public IActionResult DeleteItems(int itemId)
        {
            try
            {
                if (_adminRepository.DeleteItem(itemId))
                {
                    return Ok("Item deleted successfully");
                }
                else
                {
                    return StatusCode(500, "Error occurred while deleting item");
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"An error occurred while deleting item: {ex.Message}");
            }
        }
    }
}
