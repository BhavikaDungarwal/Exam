using Microsoft.AspNetCore.Mvc;
using ShoppingCart.Models;
using ShoppingCart.Repository;
using System;

namespace Backend.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AuthApiController : ControllerBase
    {
        private readonly IAuthRepository _authRepository;

        public AuthApiController(IAuthRepository authRepository)
        {
            _authRepository = authRepository;
        }

        [HttpPost("signup")]
        public IActionResult SignUp([FromForm] authModel auth)
        {
            if (ModelState.IsValid)
            {
                if (_authRepository.signup(auth))
                {
                    return Ok("User signed up successfully");
                }
                else
                {
                    return StatusCode(500, "Error occurred while signing up");
                }
            }
            else
            {
                return BadRequest(ModelState);
            }
        }

        [HttpPost("login")]
        public IActionResult Login([FromQuery] string email, [FromQuery] string password)
        {
            if (ModelState.IsValid)
            {
                var auth = new authModel { c_email = email, c_password = password };

                var user = _authRepository.login(auth);
                if (user != null)
                {
                    return Ok(user);
                }
                else
                {
                    return NotFound("Invalid email or password");
                }
            }
            else
            {
                return BadRequest(ModelState);
            }
        }

    }
}
