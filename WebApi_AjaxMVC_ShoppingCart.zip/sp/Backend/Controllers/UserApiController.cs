// UserApiController.cs

using Microsoft.AspNetCore.Mvc;
using ShoppingCart.Models;
using ShoppingCart.Repository;
using System;

namespace Backend.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class UserApiController : ControllerBase
    {
        private readonly IUserRepository _userRepository;

        public UserApiController(IUserRepository userRepository)
        {
            _userRepository = userRepository ;
        }

        [HttpGet("getItemDetails")]
        public IActionResult GetItemDetails()
        {
            try
            {
                var items = _userRepository.GetItemDetails();
                return Ok(items);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"An error occurred while fetching item details: {ex.Message}");
            }
        }

        [HttpGet("getItemById/{id}")]
        public IActionResult GetItemById(int id)
        {
            try
            {
                var item = _userRepository.GetItemById(id);
                if (item != null)
                {
                    return Ok(item);
                }
                else
                {
                    return NotFound($"Item with ID {id} not found");
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"An error occurred while fetching item by ID: {ex.Message}");
            }
        }

        [HttpPost("addPurchase")]
        public IActionResult AddPurchase(int customerId, int itemId, int quantity, int totalCost)
        {
            try
            {
                _userRepository.AddPurchase(customerId, itemId, quantity, totalCost);
                return Ok("Purchase added successfully");
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"An error occurred while adding purchase: {ex.Message}");
            }
        }
    }
}
