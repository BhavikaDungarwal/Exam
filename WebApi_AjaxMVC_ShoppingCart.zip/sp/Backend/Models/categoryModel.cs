using System.ComponentModel.DataAnnotations;
namespace ShoppingCart.Models
{
    public class categoryModel
    {

        public int c_categoryid { get; set; }

        [Required(ErrorMessage = "Category name is required.")]
        public string c_categoryname { get; set; }
    }
}