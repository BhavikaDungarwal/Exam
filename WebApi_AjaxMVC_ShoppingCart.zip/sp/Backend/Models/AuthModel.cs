using System.ComponentModel.DataAnnotations;
namespace ShoppingCart.Models
{


    public class authModel
    {
        public int c_userid { get; set; }

        [Required(ErrorMessage = "Name is required")]
        public string c_name { get; set; }

        [Required(ErrorMessage = "Email is required")]
        [EmailAddress(ErrorMessage = "Invalid email format")]
        public string c_email { get; set; }

        [Required(ErrorMessage = "Password is required")]
        [MinLength(6, ErrorMessage = "Password must be at least 6 characters long")]
        public string c_password { get; set; }

        [Compare("c_password", ErrorMessage = "Passwords do not match")]
        public string c_repassword { get; set; }

        public int c_role { get; set; }
    }
}
