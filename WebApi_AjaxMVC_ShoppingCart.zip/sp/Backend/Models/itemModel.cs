using System.ComponentModel.DataAnnotations;

namespace ShoppingCart.Models
{
    public class itemModel
    {
        public int c_itemid { get; set; }

    [Required(ErrorMessage = "Item name is required.")]
    [StringLength(255, ErrorMessage = "Item name must be between 1 and 255 characters.", MinimumLength = 1)]
    public string c_itemname { get; set; }

    [Display(Name = "Category")]
    [Required(ErrorMessage = "Category is required.")]
    public int c_categoryid { get; set; }

    public string c_image { get; set; }

    [Required(ErrorMessage = "Cost is required.")]
    [Range(0, int.MaxValue, ErrorMessage = "Cost must be a positive number.")]
    public int c_cost { get; set; }

    [Required(ErrorMessage = "Initial stock is required.")]
    [Range(0, int.MaxValue, ErrorMessage = "Initial stock must be a positive number.")]
    public int c_initialstock { get; set; }

    [Required(ErrorMessage = "Available stock is required.")]
    [Range(0, int.MaxValue, ErrorMessage = "Available stock must be a positive number.")]
    public int c_availablestock { get; set; }
    }
}