using System;

namespace ShoppingCart.Models
{
    public class purchaseModel
    {
        public int c_purchaseid { get; set; }
        public int c_customerid { get; set; }
        public int c_itemid { get; set; }
        public int c_quantity { get; set; }
        public int c_totalcost { get; set; }
        public DateTime c_purchasedate { get; set; }
    }
}