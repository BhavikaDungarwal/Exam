using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Employee.Models
{
    public class DesignationModel
    {
        public int c_desigid { get; set; }
        public string c_designame { get; set; }
    }
}