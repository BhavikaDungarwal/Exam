using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Employee.Models
{
    public class EmpModel
    {
        public int c_empid { get; set; }
        public string c_empname { get; set; }
        public string c_hiredate { get; set; }
        public int c_grosssalary { get; set; }
        public int c_desigid { get; set; }
        public string c_gender { get; set; }
        public int c_userid { get; set; }
    }
}