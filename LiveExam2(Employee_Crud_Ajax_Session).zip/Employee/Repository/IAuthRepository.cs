using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Employee.Models;

namespace Employee.Repository
{
    public interface IAuthRepository
    {
        bool register(AuthModel auth);

        AuthModel login(AuthModel auth);
    }
}