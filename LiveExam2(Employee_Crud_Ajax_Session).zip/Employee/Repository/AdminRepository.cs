using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Employee.Models;
using Microsoft.Extensions.Configuration;
using Npgsql;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Employee.Models;
using Employee.Repository;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace Employee.Repository
{
    public class AdminRepository : IAdminRepository
    {
        private readonly string _con;
        

        public AdminRepository(IConfiguration configuration)
        {
            _con = configuration.GetConnectionString("DefaultConnection");
        }

        public bool AddData(EmpModel model)
        {
            using (NpgsqlConnection con = new NpgsqlConnection(_con))
            {
                try
                {
                    con.Open();
                    string query = "INSERT INTO t_emp (c_empname, c_hiredate, c_grosssalary, c_desigid, c_gender, c_userid) VALUES (@Name, @HireDate, @Salary, @Designation, @Gender, @UserId)";
                    using (NpgsqlCommand cmd = new NpgsqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@Name", model.c_empname);
                        cmd.Parameters.AddWithValue("@HireDate", model.c_hiredate);
                        cmd.Parameters.AddWithValue("@Salary", model.c_grosssalary);
                        cmd.Parameters.AddWithValue("@Designation", model.c_desigid);
                        cmd.Parameters.AddWithValue("@Gender", model.c_gender);
                        cmd.Parameters.AddWithValue("@UserId", model.c_userid);
                        int rowsAffected = cmd.ExecuteNonQuery();
                        return rowsAffected > 0;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    return false;
                }
            }
        }

        public List<EmpModel> AllData()
        {
            List<EmpModel> data = new List<EmpModel>();
            using (NpgsqlConnection con = new NpgsqlConnection(_con))
            {
                try
                {
                    
                    con.Open();
                    string query = "SELECT * FROM t_emp";
                    using (NpgsqlCommand cmd = new NpgsqlCommand(query, con))
                    {
                        cmd.CommandType = CommandType.Text;
                        using (NpgsqlDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                EmpModel emp = new EmpModel
                                {
                                    c_empid = Convert.ToInt32(reader["c_empid"]),
                                    c_empname = reader["c_empname"].ToString(),
                                    c_hiredate = reader["c_hiredate"].ToString(),
                                    c_grosssalary = Convert.ToInt32(reader["c_grosssalary"]),
                                    c_gender = reader["c_gender"].ToString(),
                                    c_desigid = Convert.ToInt32(reader["c_desigid"]),
                                    c_userid = Convert.ToInt32(reader["c_userid"])
                                };
                                data.Add(emp);
                            }
                            return data;
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    return null;
                }
            }
        }


        public bool DeleteData(int id)
        {
            using (NpgsqlConnection con = new NpgsqlConnection(_con))
            {
                try
                {
                    con.Open();
                    string query = "DELETE FROM t_emp WHERE c_empid = @Id";
                    using (NpgsqlCommand cmd = new NpgsqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@Id", id);
                        int rowsAffected = cmd.ExecuteNonQuery();
                        return true;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    return false;
                }
            }
        }

        public List<DesignationModel> Designations()
        {  List<DesignationModel> data = new List<DesignationModel>();
            using (NpgsqlConnection con = new NpgsqlConnection(_con))
            {
                try
                {
                    con.Open();
                    string query = "SELECT * FROM t_designation";
                    using (NpgsqlCommand cmd = new NpgsqlCommand(query, con))
                    {
                        cmd.CommandType = CommandType.Text;
                        using (NpgsqlDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                DesignationModel design = new DesignationModel
                                {
                                    c_desigid = Convert.ToInt32(reader["c_desigid"]),
                                    c_designame = reader["c_designame"].ToString()
                                   
                                };
                                data.Add(design);
                            }
                            return data;
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    return null;
                }
            }
        }
        public List<AuthModel> user()
        {  List<AuthModel> data = new List<AuthModel>();
            using (NpgsqlConnection con = new NpgsqlConnection(_con))
            {
                try
                {
                    con.Open();
                    string query = "SELECT * FROM t_auth";
                    using (NpgsqlCommand cmd = new NpgsqlCommand(query, con))
                    {
                        cmd.CommandType = CommandType.Text;
                        using (NpgsqlDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                AuthModel design = new AuthModel
                                {
                                    c_userid = Convert.ToInt32(reader["c_userid"]),
                                    c_name = reader["c_name"].ToString()
                                   
                                };
                                data.Add(design);
                            }
                            return data;
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    return null;
                }
            }
        }

        public EmpModel GetData(int id)
        {
            using (NpgsqlConnection con = new NpgsqlConnection(_con))
            {
                try
                {
                    con.Open();
                    string query = "SELECT * FROM t_emp WHERE c_empid = @Id";
                    using (NpgsqlCommand cmd = new NpgsqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@Id", id);
                        using (NpgsqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                EmpModel emp = new EmpModel
                                {
                                    c_empid = reader.GetInt32(0),
                                    c_empname = reader.GetString(1),
                                    c_hiredate = reader.GetString(2),
                                    c_grosssalary = reader.GetInt32(3),
                                    c_desigid = reader.GetInt32(4),
                                    c_gender = reader.GetString(5),
                                    c_userid = reader.GetInt32(6)
                                };
                                return emp;
                            }
                            else
                            {
                                return null;
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    return null;
                }
            }
        }

        public bool UpdateData(EmpModel model)
        {
            using (NpgsqlConnection con = new NpgsqlConnection(_con))
            {
                try
                {
                    con.Open();
                    string query = "UPDATE t_emp SET c_empname = @Name, c_hiredate = @HireDate, c_grosssalary = @Salary, c_desigid = @Designation, c_gender = @Gender,c_userid = @UserId WHERE c_empid = @Id";
                    using (NpgsqlCommand cmd = new NpgsqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@Id", model.c_empid);
                        cmd.Parameters.AddWithValue("@Name", model.c_empname);
                        cmd.Parameters.AddWithValue("@HireDate", model.c_hiredate);
                        cmd.Parameters.AddWithValue("@Salary", model.c_grosssalary);
                        cmd.Parameters.AddWithValue("@Designation", model.c_desigid);
                        cmd.Parameters.AddWithValue("@Gender", model.c_gender);
                        cmd.Parameters.AddWithValue("@UserId", model.c_userid);
                        int rowsAffected = cmd.ExecuteNonQuery();
                        return true;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    return false;
                }
            }
        }
    }
}
