using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Employee.Models;

namespace Employee.Repository
{
    public interface IAdminRepository
    {
        List<EmpModel> AllData();
        List<DesignationModel> Designations();

        bool AddData(EmpModel model);

        bool DeleteData(int id);

        bool UpdateData(EmpModel model);

        EmpModel GetData(int id);
        List<AuthModel> user();
    }
}