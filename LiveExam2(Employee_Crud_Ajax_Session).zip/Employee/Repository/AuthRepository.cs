using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using Employee.Models;
using Npgsql;

namespace Employee.Repository
{
    public class AuthRepository : IAuthRepository
    {
        private readonly string _con;

        public AuthRepository(IConfiguration configuration)
        {
            _con = configuration.GetConnectionString("DefaultConnection");
        }
        public bool register(AuthModel auth)
        {
            using (NpgsqlConnection con = new NpgsqlConnection(_con))
            {
                try
                {
                    con.Open();
                    string query = "INSERT INTO t_auth VALUES(default,@c_name,@c_email,@c_password,@c_role)";
                    using (NpgsqlCommand cmd = new NpgsqlCommand(query, con))
                    {
                        cmd.CommandType = CommandType.Text;
                        cmd.Parameters.AddWithValue("@c_name", auth.c_name);
                        cmd.Parameters.AddWithValue("@c_email", auth.c_email);
                        cmd.Parameters.AddWithValue("@c_password", auth.c_password);
                        cmd.Parameters.AddWithValue("@c_role", 0);
                        cmd.ExecuteNonQuery();
                        return true;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    return false;
                }
            }
        }
        public AuthModel login(AuthModel auth)
        {
            using (NpgsqlConnection con = new NpgsqlConnection(_con))
            {
                try
                {
                    con.Open();
                    string query = "SELECT * FROM t_auth WHERE c_email = @email AND c_password = @c_password";
                    using (NpgsqlCommand cmd = new NpgsqlCommand(query, con))
                    {
                        cmd.CommandType = CommandType.Text;
                        cmd.Parameters.AddWithValue("@email", auth.c_email);
                        cmd.Parameters.AddWithValue("@c_password", auth.c_password);
                        using (NpgsqlDataReader reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                AuthModel model = new AuthModel
                                {
                                    c_userid = reader.GetInt32(0),
                                    c_name = reader.GetString(1),
                                    c_email = reader.GetString(2),
                                    c_password = reader.GetString(3),
                                    c_role = reader.GetInt32(4)
                                };
                                return model;
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                return null;
            }
        }

    }
}