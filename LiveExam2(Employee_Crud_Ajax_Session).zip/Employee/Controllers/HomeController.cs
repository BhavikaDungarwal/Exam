﻿using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Employee.Models;
using Employee.Repository;

namespace Employee.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private IAdminRepository _adminRepository;

        public HomeController(ILogger<HomeController> logger, IAdminRepository adminRepository)
        {
            _logger = logger;
            _adminRepository = adminRepository;
        }

        public IActionResult Index()
        {
            int? id = HttpContext.Session.GetInt32("userId");
            string? userEmail = HttpContext.Session.GetString("userEmail");
            TempData["id"] = id;
            TempData["userEmail"] = userEmail;
            return View();
        }

        [HttpGet]
        public IActionResult AllData()
        {
            var data = _adminRepository.AllData();
            return Json(data);
        }
        [HttpGet]
        public IActionResult Designations()
        {
            var data = _adminRepository.Designations();
            return Json(data);
        }

        [HttpGet]
        public IActionResult Edit(int id)
        {
            var empData = _adminRepository.GetData(id);
            if (empData == null)
            {
                return NotFound();
            }
            return Json(empData);
        }

        [HttpPost]
        public IActionResult Edit(EmpModel model)
        {
            var success = _adminRepository.UpdateData(model);
            if (success)
            {
                return Json(new { success = true });
            }
            else
            {
                return Json(new { success = false, message = "Failed to update record." });
            }
        }

        [HttpGet]
        public IActionResult Auth()
        {
            var data = _adminRepository.user();
            return Json(data);
        }
       

        [HttpPost]
        public IActionResult Delete(int id)
        {
            _adminRepository.DeleteData(id);
            return Json(new { success = true });
        }

        [HttpPost]
        public IActionResult AddData(EmpModel model)
        {
            bool success = _adminRepository.AddData(model);
            return Json(new { success });
        }

        [HttpGet]
        public IActionResult Payroll(int id)
        {
            // Fetch employee details based on id from database
            var employee =_adminRepository.GetData(id);
            if (employee == null)
            {
                return NotFound(); 
            }

            decimal basic = 0.6m * employee.c_grosssalary;
            decimal da = 0.25m * employee.c_grosssalary;
            decimal hra = 0.15m * employee.c_grosssalary;
            decimal taxableSalary = basic + da + hra;
            decimal tax = (taxableSalary > 25000) ? (0.1m * (taxableSalary - 25000)) : 0;
            decimal takeHome = basic + da + hra - tax;

            var payrollData = new
            {
                EmployeeId = employee.c_empid,
                EmployeeName = employee.c_empname,
                Designation = employee.c_desigid,
                GrossSalary = employee.c_grosssalary,
                Basic = basic,
                DA = da,
                HRA = hra,
                TaxableSalary = taxableSalary,
                Tax = tax,
                TakeHome = takeHome
            };

            return Json(payrollData);
        }

        

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
